package com.capgemini.springBootMedical.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "msgrequest")
public class RequestBean {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name ="msgId")
	private int mgsId;
	@Column
	private int uId;
	@Column
	private String emailId;
	@Column
	private String msgReq;

	//getters and setters
	public int getMgsId() {
		return mgsId;
	}

	public void setMgsId(int mgsId) {
		this.mgsId = mgsId;
	}

	public int getuId() {
		return uId;
	}

	public void setuId(int uId) {
		this.uId = uId;
	}
 
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMsgReq() {
		return msgReq;
	}

	public void setMsgReq(String msgReq) {
		this.msgReq = msgReq;
	}

}
