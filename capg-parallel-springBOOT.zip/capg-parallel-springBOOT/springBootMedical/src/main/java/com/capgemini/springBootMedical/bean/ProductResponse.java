package com.capgemini.springBootMedical.bean;

import java.util.List;

public class ProductResponse {
	
	private int statusCode;
	private String message;
	private String description;
	private ProductBean productBean;
	private CartBean cartBean;
	private Adminuser userBean;
	private List<ProductBean> productList;
	private List<Adminuser> userList;
	private List<CartBean>cartList;
	private String role;
	private List<Adminuser> adminList;
	
	public List<Adminuser> getAdminList() {
		return adminList;
	}
	public void setAdminList(List<Adminuser> adminList) {
		this.adminList = adminList;
	}
	public List<CartBean> getCartList() {
		return cartList;
	}
	public void setCartList(List<CartBean> cartList) {
		this.cartList = cartList;
	}
	public String getRole() {
		return role;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public ProductBean getProductBean() {
		return productBean;
	}
	public void setProductBean(ProductBean productBean) {
		this.productBean = productBean;
	}
	public List<ProductBean> getProductList() {
		return productList;
	}
	public void setProductList(List<ProductBean> productList) {
		this.productList = productList;
	}
	public Adminuser getUserBean() {
		return userBean;
	}
	public void setUserBean(Adminuser userBean) {
		this.userBean = userBean;
	}
	public List<Adminuser> getUserList() {
		return userList;
	}
	public void setUserList(List<Adminuser> userList) {
		this.userList = userList;
	}
	public CartBean getCartBean() {
		return cartBean;
	}
	public void setCartBean(CartBean cartBean) {
		this.cartBean = cartBean;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
}
