package com.capgemini.springBootMedical.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springBootMedical.bean.Adminuser;
import com.capgemini.springBootMedical.bean.CartBean;
import com.capgemini.springBootMedical.bean.ProductBean;
import com.capgemini.springBootMedical.bean.ProductResponse;
import com.capgemini.springBootMedical.service.DaoService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", allowCredentials = "true")
public class MedicineController {

	@Autowired
	private DaoService service;

	int uId = 0;

	@PostMapping(path = "/adminLogin")
	public ProductResponse adminLogin(@RequestBody Adminuser adminuser, HttpSession session) {
		String emailId = adminuser.getEmailId();
		String password = adminuser.getPassword();
		String role = adminuser.getRole();
		Adminuser admin = service.adminLogin(emailId, password, role);
		ProductResponse response = new ProductResponse();
		if (admin != null) {
			System.out.println("session created");
			session.setAttribute("user", admin);
			uId = admin.getuId();
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("You are Logged In Successfully");
			response.setRole(admin.getRole());

		} else {
			response.setStatusCode(401);
			response.setMessage("Fail");
			response.setDescription("Unable to login..please try again!!");
		}
		return response;
	}// end of adminlogin

//__________________________________________________Product________________________________________________________

	@GetMapping(path = "/getAllProduct", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public ProductResponse getProducts() {
		List<ProductBean> productList = service.getProducts();
		ProductResponse response = new ProductResponse();
		if (productList != null) { // && !productList.isEmpty()
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Medicine record found");
			response.setProductList(productList);

		} else {
			response.setStatusCode(401);
			response.setMessage("Fail");
			response.setDescription("Medicine record not found");
		}
		return response;
	}// end of getAllProduct

	@PostMapping(path = "/addProduct", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = MediaType.APPLICATION_JSON_VALUE)
	// @ResponseBody
	public ProductResponse addProduct(@RequestBody ProductBean productBean) {
		boolean isAdded = service.addProduct(productBean);
		ProductResponse response = new ProductResponse();
		if (isAdded) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("product added successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("fail");
			response.setDescription("product not added ");
		}
		return response;

	}// end of addProduct

	@DeleteMapping(path = "/deleteProduct/{pId}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	// @ResponseBody
	public ProductResponse deleteProduct(@PathVariable int pId) {
		boolean isDeleted = service.deleteProduct(pId);
		ProductResponse response = new ProductResponse();
		if (isDeleted) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("product deleted successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("fail");
			response.setDescription("product not deleted ");
		}
		return response;

	}// end of deleteProduct

	@PostMapping(path = "/updateProduct", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = MediaType.APPLICATION_JSON_VALUE)
	// @ResponseBody
	public ProductResponse updateProduct(@RequestBody ProductBean productBean) {
		ProductBean bean1 = service.updateProduct(productBean);
		ProductResponse response = new ProductResponse();
		if (bean1 != null) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Product updated successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("fail");
			response.setDescription("Product not updated ");
		}
		return response;

	}// end of updateProduct

//____________________________________________________USER_______________________________________________________________


	@PutMapping(path = "/addUser", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = MediaType.APPLICATION_JSON_VALUE)
	// @ResponseBody
	public ProductResponse addUser(@RequestBody Adminuser userBean) {
		boolean isAdded = service.addUser(userBean);
		ProductResponse response = new ProductResponse();
		if (isAdded) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("New User added successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("fail");
			response.setDescription("user not added ");
		}
		return response;

	}// end of addUser

	@DeleteMapping(path = "/deleteUser/{uId}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	// @ResponseBody
	public ProductResponse deleteUser(@PathVariable int uId) {
		boolean isDeleted = service.deleteUser(uId);
		ProductResponse response = new ProductResponse();
		if (isDeleted) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("product deleted successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("fail");
			response.setDescription("product not deleted ");
		}
		return response;

	}// end of deleteUser

	@PostMapping(path = "/updateUser", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = MediaType.APPLICATION_JSON_VALUE)
	// @ResponseBody
	public ProductResponse updateUser(@RequestBody Adminuser userBean) {
		boolean isUpdated = service.updateUser(userBean.getuId(), userBean);
		ProductResponse response = new ProductResponse();
		if (isUpdated) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("User Record updated successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("fail");
			response.setDescription("User Record not updated ");
		}
		return response;

	}// end of updateUser

	@PostMapping(path = "/registerUser")
	// @ResponseBody
	public ProductResponse registerUser(@RequestBody Adminuser userBean) {
		System.out.println(userBean);
		boolean isAdded = service.registerUser(userBean);
		ProductResponse response = new ProductResponse();
		if (isAdded) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("User added successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("fail");
			response.setDescription("user not added ");
		}
		return response;

	}// end of registerProduct

//___________________________________________________CART_______________________________________________________________	

	@GetMapping(path = "/getCart", produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public ProductResponse getCart() {
		List<CartBean> cartBean = service.getCart(uId);
		System.out.println("......................" + cartBean);
		ProductResponse response = new ProductResponse();
		if (cartBean != null && !cartBean.isEmpty()) {

			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("User's records found");
			response.setCartList(cartBean);

		} else {
			response.setStatusCode(401);
			response.setMessage("Fail");
			response.setDescription("user Id: " + uId + "not found");
		}
		return response;
	}// end of getCart

	@PutMapping(path = "/addToCart/{pName}/{pQuantity}", produces = MediaType.APPLICATION_JSON_VALUE)
	// @ResponseBody
	public ProductResponse addToCart(@PathVariable String pName, @PathVariable int pQuantity) {

		ProductResponse response = new ProductResponse();
		if (service.addToCart(uId, pName, pQuantity)) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("product added successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("fail");
			response.setDescription("product not added ");
		}
		return response;

	}// end of addToCart

	@DeleteMapping(path = "/deleteFromCart/{cId}")
	// @ResponseBody
	public ProductResponse deleteFromCart(@PathVariable int cId) {
		System.out.println(".........................."+cId);
		boolean isDeleted = service.deleteFromCart(cId);
		ProductResponse response = new ProductResponse();
		if (isDeleted) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("products in cart get deleted successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("fail");
			response.setDescription("products are not get deleted ");
		}
		return response;

	}// end of deleteFromCart

	@GetMapping(path = "/payment", produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public ProductResponse payment(@RequestParam int uId) {
		double payment = service.payment(uId);
		ProductResponse response = new ProductResponse();
		if (payment != 0) {

			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Your Total bill is " + payment + "Payment done..!!");

		} else {
			response.setStatusCode(401);
			response.setMessage("Fail");
			response.setDescription("Payment failed...");
		}
		return response;
	}// end of payment

	@GetMapping(path = "/getRequest", produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public ProductResponse sendRequest(int uId, String msgReq) {
		boolean isSent = service.sendRequest(uId, msgReq);
		ProductResponse response = new ProductResponse();
		if (isSent) {

			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Message request comes");

		} else {
			response.setStatusCode(401);
			response.setMessage("Fail");
			response.setDescription("user Id: " + uId + "not found");
		}
		return response;
	}// end of getCart

	@PutMapping(path = "/sendReply", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = MediaType.APPLICATION_JSON_VALUE)
	// @ResponseBody
	public ProductResponse sendReply(int uId, String msgReply) {
		boolean isSend = service.sendReply(uId, msgReply);
		ProductResponse response = new ProductResponse();
		if (isSend) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Message send successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("fail");
			response.setDescription("message does not sent ");
		}
		return response;

	}// end of registerProduct

	@GetMapping(path = "/getAdmin", produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public ProductResponse getAdmin() {
		List<Adminuser> adminList = service.getAdmin();
		ProductResponse response = new ProductResponse();
		if (adminList != null) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Admin Logged In Successfuly");
			response.setAdminList(adminList);

		} else {
			response.setStatusCode(401);
			response.setMessage("Fail");
			response.setDescription("Unable to login..please try again!!");
		}
		return response;
	}// end of userlogin

	@GetMapping(path = "/getUser", produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public ProductResponse getUser() {
		List<Adminuser> adminList = service.getUser();
		ProductResponse response = new ProductResponse();
		if (adminList != null) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("User Logged In Successfuly");
			response.setAdminList(adminList);

		} else {
			response.setStatusCode(401);
			response.setMessage("Fail");
			response.setDescription("Unable to login..please try again!!");
		}
		return response;
	}// end of userlogin

	@GetMapping(path = "/getPerticularUser", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public ProductResponse getPerticularUser() {
		List<Adminuser> userList = service.getPerticularUser(uId);
		ProductResponse response = new ProductResponse();
		if (userList != null) { // && !productList.isEmpty()
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("Medicine record found");
			response.setUserList(userList);

		} else {
			response.setStatusCode(401);
			response.setMessage("Fail");
			response.setDescription("Medicine record not found");
		}
		return response;
	}// end of getAllProduct

	@PostMapping(path = "/updateAdminProfile", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = MediaType.APPLICATION_JSON_VALUE)
	// @ResponseBody
	public ProductResponse updateAdminProfile(@RequestBody Adminuser userBean) {
		boolean isUpdated = service.updateAdmin(userBean.getuId(), userBean);
		ProductResponse response = new ProductResponse();
		if (isUpdated) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("User Record updated successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("fail");
			response.setDescription("User Record not updated ");
		}
		return response;

	}// end of updateUser

	@PutMapping(path = "/register", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	// @ResponseBody
	public ProductResponse register(@RequestBody Adminuser userBean) {

		String emailId = userBean.getEmailId();
		if (!service.customEmailValidation(emailId)) {
			boolean isAdd = service.registerUser(userBean);
			ProductResponse response = new ProductResponse();

			if (isAdd) {
				response.setStatusCode(201);
				response.setMessage("Success");
				response.setDescription("User registered successfully");
			} else {
				response.setStatusCode(401);
				response.setMessage("Failed");
				response.setDescription(" Sorry , Unable to register user...");
			}
			return response;
		} else {
			ProductResponse response = new ProductResponse();
			response.setStatusCode(401);
			response.setMessage("Failed");
			response.setDescription(" Sorry ,Enter email is already exist...");
			return response;

		}

	}// end of register()

}