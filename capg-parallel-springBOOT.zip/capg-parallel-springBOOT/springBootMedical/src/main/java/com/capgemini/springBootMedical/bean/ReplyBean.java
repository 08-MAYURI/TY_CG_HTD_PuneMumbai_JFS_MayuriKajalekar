package com.capgemini.springBootMedical.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "msgreply")
public class ReplyBean {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private int replyId;
	@Column
	private int uId;
	@Column
	private String emailId;
	@Column
	private String msgReply;

	//getters and setters
	public int getReplyId() {
		return replyId;
	}

	public void setReplyId(int replyId) {
		this.replyId = replyId;
	}

	public int getuId() {
		return uId;
	}

	public void setuId(int uId) {
		this.uId = uId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMsgReply() {
		return msgReply;
	}

	public void setMsgReply(String msgReply) {
		this.msgReply = msgReply;
	}


}

