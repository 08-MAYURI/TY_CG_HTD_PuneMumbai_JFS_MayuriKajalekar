package com.capgemini.springBootMedical;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMedicalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMedicalApplication.class, args);
	}

}
