package com.capgemini.springBootMedical.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.springBootMedical.bean.Adminuser;
import com.capgemini.springBootMedical.bean.CartBean;
import com.capgemini.springBootMedical.bean.ProductBean;
import com.capgemini.springBootMedical.bean.ReplyBean;
import com.capgemini.springBootMedical.bean.RequestBean;

@Repository
public class DaoImpl implements Dao {
	@PersistenceUnit
	EntityManagerFactory emf;

	@Override
	public List<ProductBean> getProducts() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from ProductBean";
		Query query = manager.createQuery(jpql);

		List<ProductBean> productList = null;
		try {
			productList = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return productList;

	}

	@Override
	public Adminuser adminLogin(String emailId, String password, String role) {
		System.out.println("..................................." + emailId);
		EntityManager entityManager = emf.createEntityManager();
		EntityTransaction tx = entityManager.getTransaction();
		Adminuser bean = null;
		tx.begin();
		String jpql = "from Adminuser where emailId=:emailId and password=:password ";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("emailId", emailId);
		query.setParameter("password", password);
		// query.setParameter("role", role);

		try {
			bean = (Adminuser) query.getSingleResult();
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public boolean deleteProduct(int pId) {
		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			ProductBean bean = entityManager.find(ProductBean.class, pId);
			entityManager.remove(bean);
			tx.commit();
			isDeleted = true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		entityManager.close();
		return isDeleted;
	}

	@Override
	public boolean addProduct(ProductBean bean) {
		EntityManager entityManager = emf.createEntityManager();
		boolean isAdded = false;
		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			entityManager.persist(bean);
			tx.commit();
			isAdded = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		entityManager.close();

		return isAdded;

	}

	@Override
	public ProductBean updateProduct(ProductBean bean) {
		EntityManager entityManager = emf.createEntityManager();
		ProductBean Bean1 = entityManager.find(ProductBean.class, bean.getpId());

		if (Bean1.getpName() != null) {
			Bean1.setpName(bean.getpName());
		}
		if (Bean1.getpCategory() != null) {
			Bean1.setpCategory(bean.getpCategory());
		}
		if (Bean1.getpQuantity() != 0) {
			Bean1.setpQuantity(bean.getpQuantity());
		}
		if (Bean1.getpPrice() != 0) {
			Bean1.setpPrice(bean.getpPrice());
		}

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			entityManager.persist(Bean1);
			tx.commit();

		} catch (Exception e) {
			e.printStackTrace();
		}
		entityManager.close();
		return Bean1;

	}

	@Override
	public boolean deleteUser(int uId) {

		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			Adminuser bean = entityManager.find(Adminuser.class, uId);
			entityManager.remove(bean);
			tx.commit();
			isDeleted = true;
			if (isDeleted = true) {
				System.out.println("USER DELETED");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		entityManager.close();
		return isDeleted;

	}

	@Override
	public List<Adminuser> getUser() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from Adminuser where role=:role";
		Query query = manager.createQuery(jpql);
		query.setParameter("role", "user");
		List<Adminuser> userList = null;
		try {
			userList = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return userList;

	}

	@Override
	public List<Adminuser> getPerticularUser(int uId) {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from Adminuser where role=:role  AND uId=:uId";
		Query query = manager.createQuery(jpql);
		query.setParameter("role", "user");
		query.setParameter("uId", uId);
		List<Adminuser> userList1 = null;
		try {
			userList1 = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return userList1;

	}

	@Override
	public boolean sendReply(int uId, String msgReply) {
		boolean isSent = false;

		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();

		String emailId = null;

		String jpql = "from Adminuser where uId=:uId";
		Query query = manager.createQuery(jpql);
		query.setParameter("uId", uId);
		List<Adminuser> list = query.getResultList();
		for (Adminuser li : list) {
			emailId = li.getEmailId();

		}

		ReplyBean bean = new ReplyBean();
		bean.setuId(uId);
		bean.setEmailId(emailId);
		bean.setMsgReply(msgReply);
		tx.begin();
		manager.persist(bean);
		isSent = true;
		tx.commit();

		return isSent;

	}

	@Override
	public List<RequestBean> seeRequest() {

		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		tx.begin();
		String jpql = "from msgrequest";

		Query query = manager.createQuery(jpql);

		List<RequestBean> list = query.getResultList();

		tx.commit();
		return list;
	}

	@Override
	public Adminuser userLogin(String emailId, String password, String mobileNo, String role, String address) {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from Adminuser where emailId=:emailId and password=:password and role=:role and mobileNo:=mobileNo and address:=address";
		Query query = manager.createQuery(jpql);
		query.setParameter("emailId", emailId);
		query.setParameter("password", password);
		query.setParameter("role", role);
		query.setParameter("mobileNo", mobileNo);
		query.setParameter("address", address);
		int uId = 0;
		Adminuser bean = null;
		try {
			bean = (Adminuser) query.getSingleResult();
			uId = bean.getuId();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bean;
	}

	@Override
	public boolean addUser(Adminuser user) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		boolean isAdded = false;

		try {
			tx.begin();
			manager.persist(user);
			tx.commit();
			isAdded = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		manager.close();

		return isAdded;
	}

	@Override
	public boolean updateUser(int uId, Adminuser bean) {
		EntityManager entityManager = emf.createEntityManager();

		Adminuser Bean2 = entityManager.find(Adminuser.class, uId);

		EntityTransaction tx = entityManager.getTransaction();
		boolean isupdated = false;
		if (Bean2 != null) {
			String emailId = bean.getEmailId();
			if (emailId != null) {
				Bean2.setEmailId(emailId);
			}
			String pass = bean.getPassword();
			if (pass != null) {
				Bean2.setPassword(pass);
			}
			String mobileNo = bean.getMobileNo();
			if (mobileNo != null) {
				Bean2.setMobileNo(mobileNo);
			}
			String address = bean.getAddress();
			if (address != null) {
				Bean2.setMobileNo(address);
			}

		}
		try {
			tx.begin();
			entityManager.persist(Bean2);
			tx.commit();
			isupdated = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		entityManager.close();

		return isupdated;

	}

//	@Override
//	public boolean addToCart(int uId, ProductBean productBean, int quantity) {
//		boolean isAdded = false;
//		String emailId = null;
//		String category = null;
//		double pPrice = 0;
//		int id = 0;
//
//		EntityManager manager = emf.createEntityManager();
//		EntityTransaction tx = manager.getTransaction();
//		tx.begin();
//		CartBean cartBean = new CartBean();
//		String jpql = " from Adminuser where uId=:uId";
//		// int userId = cartBean.getuId();
//
//		Query query = manager.createQuery(jpql);
//		query.setParameter("uId", uId);
//		List<Adminuser> list = query.getResultList();
//		for (Adminuser li : list) {
//			emailId = li.getEmailId();
//
//		}
//		// Scanner scan = new Scanner(System.in);
//
//		// String jpql1 = "from ProductBean where pName=:pName";
//		// Query query1 = manager.createQuery(jpql1);
//
//		// query1.setParameter("pName", pName);
//		// List<ProductBean> list1 = query1.getResultList();
//		// for (ProductBean li : list1) {
//		category = productBean.getpCategory();
//		id = productBean.getpId();
//		String pName = productBean.getpName();
//		pPrice = productBean.getpPrice();
//
//		// }
//
//		CartBean c = new CartBean();
//		// c.setcId(10);
//		c.setpCategory(category);
//		c.setpName(pName);
//		c.setpId(id);
//		c.setEmailId(emailId);
//		c.setQuantity(quantity);
//		c.setuId(uId);
//
//		manager.persist(c);
//		isAdded = true;
//		tx.commit();
//		if (c != null) {
//			System.out.println("PRODUCT INSERTED");
//		}
//		return isAdded;
//	}

	@Override
	public boolean addToCart(int uId, String pName, int pQuantity) {

		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();

		String jpql = "from Adminuser where uId=:uId";
		Query query1 = manager.createQuery(jpql);
		query1.setParameter("uId", uId);
		try {
			query1.getSingleResult();
		} catch (Exception e) {
			return false;
		}
		String query2 = "from ProductBean  where pName=:pName";
		Query query = manager.createQuery(query2);
		query.setParameter("pName", pName);
		List<ProductBean> productBeans = (List<ProductBean>) query.getResultList();
		if (productBeans.size() == 0) {
			return false;
		}
		try {
			tx.begin();
			for (ProductBean productBean : productBeans) {
				CartBean cart = new CartBean();
				cart.setpId(productBean.getpId());
				cart.setuId(uId);
				cart.setpName(pName);
				cart.setpPrice(productBean.getpPrice());
				cart.setQuantity(pQuantity);
				manager.persist(cart);
			}
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		manager.close();
		return true;
	}

	@Override
	public boolean deleteFromCart(int cId) {
		System.out.println(".............................."+cId);
		EntityManager entityManager = emf.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			CartBean cart = entityManager.find(CartBean.class, cId);
			entityManager.remove(cart);

			tx.commit();
			isDeleted = true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		entityManager.close();
		return isDeleted;
	}

	@Override
	public double payment(int uId) {
		double bill = 0;

		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		tx.begin();
		String jpql = "select SUM(pPrice*quantity) from CartBean where uId=:uId";

		Query query1 = manager.createQuery(jpql);
		query1.setParameter("uId", uId);

		List<Double> list1 = query1.getResultList();

		for (Double li : list1) {
			bill = li.doubleValue();
			System.out.println("TOTAL BILL IS" + bill);

		}
		tx.commit();
		return bill;
	}

	@Override
	public boolean sendRequest(int uId, String msgReq) {
		boolean isSent = false;

		EntityManager entityManager = emf.createEntityManager();
		EntityTransaction tx = entityManager.getTransaction();

		String emailId = null;
		String jpql = "from Adminuser where uId=:uId";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("uId", uId);
		List<Adminuser> list = query.getResultList();
		for (Adminuser li : list) {
			emailId = li.getEmailId();

		}

		RequestBean bean = new RequestBean();
		bean.setuId(uId);
		bean.setEmailId(emailId);
		bean.setMsgReq(msgReq);
		tx.begin();
		entityManager.persist(bean);
		isSent = true;
		tx.commit();
		if (bean != null) {
			System.out.println("MESSAGE SENT SUCCESSFULLY");
		}
		return isSent;
	}

	@Override
	public List<ReplyBean> seeReply(int uId) {

		EntityManager entityManager = emf.createEntityManager();
		String jpql = "from msgReply where uId=:uId";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("uId", uId);
		String msg = null;
		List<ReplyBean> list = query.getResultList();

		return list;
	}

	@Override
	public List<CartBean> getCart(int uId) {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from CartBean where uId=:uId";
		Query query = manager.createQuery(jpql);
		query.setParameter("uId", uId);

		List<CartBean> list = query.getResultList();

		return list;

	}

	@Override
	public boolean registerUser(Adminuser bean) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		boolean isAdded = false;

		try {
			tx.begin();
			manager.persist(bean);
			tx.commit();
			isAdded = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		manager.close();

		return isAdded;
	}

	@Override
	public List<Adminuser> getAdmin() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from Adminuser where role=:role";
		Query query = manager.createQuery(jpql);
		query.setParameter("role", "admin");
		List<Adminuser> adminList = null;
		try {
			adminList = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return adminList;

	}

	@Override
	public boolean updateAdmin(int uId, Adminuser bean) {
		EntityManager entityManager = emf.createEntityManager();

		Adminuser Bean2 = entityManager.find(Adminuser.class, uId);

		EntityTransaction tx = entityManager.getTransaction();
		boolean isupdated = false;
		if (Bean2 != null) {
			String emailId = bean.getEmailId();
			if (emailId != null) {
				Bean2.setEmailId(emailId);
			}
			String pass = bean.getPassword();
			if (pass != null) {
				Bean2.setPassword(pass);
			}
			String mobileNo = bean.getMobileNo();
			if (mobileNo != null) {
				Bean2.setMobileNo(mobileNo);
			}
			String address = bean.getAddress();
			if (address != null) {
				Bean2.setMobileNo(address);
			}

		}
		try {
			tx.begin();
			entityManager.persist(Bean2);
			tx.commit();
			isupdated = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		entityManager.close();

		return isupdated;

	}

	@Override
	public boolean customEmailVaidation(String emailId) {

		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		boolean isValid = false;

		String jpql = " from Registration";
		transaction.begin();
		Query query = em.createQuery(jpql);
		List<Adminuser> list = null;
		try {
			list = query.getResultList();
			for (Adminuser user : list) {
				if (emailId.equals(user.getEmailId())) {
					isValid = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isValid;
	}

//	@Override
//	public Adminuser authenticateUser(String emailId, String password) {
//		// TODO Auto-generated method stub
//		return null;
//	}
}
