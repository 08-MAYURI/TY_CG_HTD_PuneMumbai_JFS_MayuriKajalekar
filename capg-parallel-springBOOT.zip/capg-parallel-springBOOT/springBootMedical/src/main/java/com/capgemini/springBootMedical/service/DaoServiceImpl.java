package com.capgemini.springBootMedical.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.springBootMedical.bean.Adminuser;
import com.capgemini.springBootMedical.bean.CartBean;
import com.capgemini.springBootMedical.bean.ProductBean;
import com.capgemini.springBootMedical.bean.ReplyBean;
import com.capgemini.springBootMedical.bean.RequestBean;
import com.capgemini.springBootMedical.dao.Dao;

@Service
public class DaoServiceImpl implements DaoService {
	@Autowired
	private Dao dao;

	@Override
	public List<ProductBean> getProducts() {
		return dao.getProducts();
	}

	@Override
	public Adminuser adminLogin(String emailId, String password, String role) {
		return dao.adminLogin(emailId, password, role);
	}

	@Override
	public boolean deleteProduct(int pId) {
		return dao.deleteProduct(pId);
	}

	@Override
	public boolean addProduct(ProductBean bean) {
		return dao.addProduct(bean);
	}

	@Override
	public ProductBean updateProduct(ProductBean bean) {
		return dao.updateProduct(bean);
	}

	@Override
	public boolean deleteUser(int uId) {

		return dao.deleteUser(uId);
	}

	@Override
	public List<Adminuser> getUser() {
		return dao.getUser();
	}

	@Override
	public boolean sendReply(int uId, String msgReply) {
		return dao.sendReply(uId, msgReply);
	}

	@Override
	public List<RequestBean> seeRequest() {
		return dao.seeRequest();

	}

	@Override
	public Adminuser userLogin(String emailId, String password, String role, String mobileNo, String address) {
		return dao.userLogin(emailId, password, role, mobileNo, address);
	}

	@Override
	public boolean addUser(Adminuser user) {
		return dao.addUser(user);
	}

	@Override
	public boolean updateUser(int uId, Adminuser bean) {
		return dao.updateUser(uId, bean);
	}

	@Override
	public boolean deleteFromCart(int cId) {
		return dao.deleteFromCart(cId);

	}

	@Override
	public double payment(int uId) {
		return dao.payment(uId);
	}

	@Override
	public boolean sendRequest(int uId, String msgReq) {
		return dao.sendRequest(uId, msgReq);
	}

	@Override
	public List<ReplyBean> seeReply(int uId) {
		return dao.seeReply(uId);
	}

	@Override
	public List<CartBean> getCart(int uId) {
		return dao.getCart(uId);
	}

	@Override
	public boolean registerUser(Adminuser bean) {
		return dao.registerUser(bean);
	}

	@Override
	public List<Adminuser> getAdmin() {
		return dao.getAdmin();
	}

	@Override
	public boolean updateAdmin(int uId, Adminuser bean) {
		return dao.updateAdmin(uId, bean);
	}

	@Override
	public List<Adminuser> getPerticularUser(int uId) {
		return dao.getPerticularUser(uId);
	}

	@Override
	public boolean customEmailValidation(String emailId) {
		return dao.customEmailVaidation(emailId);
	}

	@Override
	public boolean addToCart(int uId, String pName, int pQuantity) {
		return dao.addToCart(uId, pName, pQuantity);
	}

}