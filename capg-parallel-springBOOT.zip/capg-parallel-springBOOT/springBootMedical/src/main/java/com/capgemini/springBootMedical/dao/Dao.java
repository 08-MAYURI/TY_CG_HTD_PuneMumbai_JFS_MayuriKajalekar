package com.capgemini.springBootMedical.dao;

import java.util.List;

import com.capgemini.springBootMedical.bean.Adminuser;
import com.capgemini.springBootMedical.bean.CartBean;
import com.capgemini.springBootMedical.bean.ProductBean;
import com.capgemini.springBootMedical.bean.ReplyBean;
import com.capgemini.springBootMedical.bean.RequestBean;

public interface Dao {

	public List<ProductBean> getProducts();

	public boolean registerUser(Adminuser bean);

	public boolean addProduct(ProductBean bean);

	public boolean deleteProduct(int pId);

	public ProductBean updateProduct(ProductBean bean);

	public Adminuser userLogin(String emailId, String password, String role, String mobileNo, String address);

	public List<Adminuser> getUser();

	public boolean addUser(Adminuser user);

	public boolean updateUser(int uId, Adminuser bean);

	public boolean updateAdmin(int uId, Adminuser bean);

	public boolean deleteUser(int uId);

	public boolean sendReply(int uId, String msgReply);

	public List<RequestBean> seeRequest();

	public List<CartBean> getCart(int uId);

	public double payment(int uId);

	public boolean sendRequest(int uId, String msgReq);

	public List<ReplyBean> seeReply(int uId);

//	public boolean addToCart(ProductBean productBean);

	public List<Adminuser> getAdmin();

	public List<Adminuser> getPerticularUser(int uId);

	public Adminuser adminLogin(String emailId, String password, String role);

	public boolean customEmailVaidation(String emailId);

	public boolean deleteFromCart(int cId);

	public boolean addToCart(int uId, String pName, int pQuantity);

	// public Adminuser authenticateUser(String emailId, String password);
}// end of dao
