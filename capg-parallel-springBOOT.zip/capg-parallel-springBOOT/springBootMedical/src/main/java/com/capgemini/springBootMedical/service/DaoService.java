package com.capgemini.springBootMedical.service;

import java.util.List;

import com.capgemini.springBootMedical.bean.Adminuser;
import com.capgemini.springBootMedical.bean.CartBean;
import com.capgemini.springBootMedical.bean.ProductBean;
import com.capgemini.springBootMedical.bean.ReplyBean;
import com.capgemini.springBootMedical.bean.RequestBean;

public interface DaoService {

	public List<ProductBean> getProducts();

	public boolean deleteProduct(int pId);

	public boolean addProduct(ProductBean bean);

	public ProductBean updateProduct(ProductBean bean);

	public boolean deleteUser(int uId);

	public List<Adminuser> getUser();

	public List<Adminuser> getAdmin();

	public boolean sendReply(int uId, String msgReply);

	public List<RequestBean> seeRequest();

	public boolean addUser(Adminuser user);

	public boolean updateUser(int uId, Adminuser bean);

	public boolean updateAdmin(int uId, Adminuser bean);

	public List<Adminuser> getPerticularUser(int uId);

	public List<CartBean> getCart(int uId);

	public double payment(int uId);

	public boolean sendRequest(int uId, String msgReq);

	public List<ReplyBean> seeReply(int uId);

	public boolean registerUser(Adminuser userBean);

	public Adminuser userLogin(String emailId, String password, String role, String mobileNo, String address);

	public Adminuser adminLogin(String emailId, String password, String role);

	public boolean customEmailValidation(String emailId);

	public boolean deleteFromCart(int cId);

	public boolean addToCart(int uId, String pName, int pQuantity);

//public Adminuser authenticateUser(String emailId, String password);

}
