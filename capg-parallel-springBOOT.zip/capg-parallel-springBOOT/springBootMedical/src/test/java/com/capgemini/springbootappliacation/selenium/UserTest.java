package com.capgemini.springbootappliacation.selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class UserTest {

	static {
		System.setProperty("webdriver.gecko.driver", "./resources/geckodriver.exe");
	}
	public static void main(String[] args) {
		
		WebDriver driver =new FirefoxDriver();
		driver.get("http://localhost:4200/login");
		
		// Admin login
		driver.findElement(By.name("email")).sendKeys("shital@gmail.com");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		//password
		driver.findElement(By.name("password")).sendKeys("Shital@123");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	
		//login button
		driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/form/div[3]/button"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//add product to cart
		driver.findElement(By.xpath("//a[text()='Add Product to cart']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
	
		
		//add product button
		driver.findElement(By.xpath("/html/body/app-add-product/div/div/form/div[3]/button"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//card page should be displayed
		driver.findElement(By.xpath("//a[text()=' Payment']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
		//admin see all user
		driver.findElement(By.xpath("//a[text()='See All User']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
		// admin see request
		driver.findElement(By.xpath("//a[text()='See Request']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
		//type message
		driver.findElement(By.name("reply")).sendKeys("hiiii");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		//send  reply to user
		driver.findElement(By.xpath("/html/body/app-see-all-messages/div/div/form/div[3]/button"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	


}
