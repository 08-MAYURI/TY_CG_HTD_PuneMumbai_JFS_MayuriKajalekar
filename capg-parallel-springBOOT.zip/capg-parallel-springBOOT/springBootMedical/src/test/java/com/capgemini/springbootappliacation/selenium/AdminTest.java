package com.capgemini.springbootappliacation.selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AdminTest {

	static {
		System.setProperty("webdriver.gecko.driver", "./resources/geckodriver.exe");
	}
	public static void main(String[] args) {
		
		WebDriver driver =new FirefoxDriver();
		driver.get("http://localhost:4200/login");
		
		// Admin login
		driver.findElement(By.name("email")).sendKeys("mayuri@gmail.com");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		//password
		driver.findElement(By.name("password")).sendKeys("mayuri@123");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	
		//login button
		driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/form/div[3]/button"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//add product
		driver.findElement(By.xpath("//a[text()='Add Product']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
	
		//enter category of product
		driver.findElement(By.name("category")).sendKeys("health care");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//add product button
		driver.findElement(By.xpath("/html/body/app-add-product/div/div/form/div[3]/button"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//on dashboard product must be displayed
		driver.findElement(By.xpath("//a[text()=' Products']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
		//admin see all user
		driver.findElement(By.xpath("//a[text()='See All User']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
		// admin see request
		driver.findElement(By.xpath("//a[text()='See Request']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
		//type message
		driver.findElement(By.name("reply")).sendKeys("hiiii");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		//send  reply to user
		driver.findElement(By.xpath("/html/body/app-see-all-messages/div/div/form/div[3]/button"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
}
