export class Rectangle{
    perimeter(l: number, b: number): number{
        return 2*(l+b);
    }

    areaOfRectangle(l: number,b: number): number{
        return l*b;
    }
}