import {Circle} from './circle';
import {Rectangle} from './rectangle';

let circle = new Circle();
let rectangle =new Rectangle();

console.log(circle.areaOfCircle(23));
console.log(rectangle.areaOfRectangle(12,43));