var a = 100;
var b =200;
console.log(a);
console.log(b);

//annonymous function with expresssion
var x = function(){
    console.log('Hello fro anonymous');
}

//calling a function
x();


//naming function
function add(a,b){
    console.log(a+b);
}

//calling a naming function 
add(12,12);

//immediate invoke function calling

(function(x,y){
    console.log('IIFE is being executed');
    console.log('value is ',x*y);
})(4,6);

//understanding a return  keyword

function division(a,b){
    return (a/b);

}console.log('division is ',division(69,13));