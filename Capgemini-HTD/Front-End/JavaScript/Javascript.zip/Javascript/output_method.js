//alert("Are you sure want to proceed");

//var inputFromUser = confirm("Are you sure want to proceed");

//console.log(inputFromUser);

var userName = prompt("please enter your name");
console.log(userName);

console.log(12345678);

document.write('good morning guys');