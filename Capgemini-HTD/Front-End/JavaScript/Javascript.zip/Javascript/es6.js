//spread operator

let person={
    name: 'anushka',
    age:30
};

let student = {
    ...person,
    uid:1234,
    percentage :65.98
};

console.log(student);

let mumbaiCRS =['aakash','aishwarya'];
let noidaCRS = ['manali','karthik'];
let bangaloreCRS = ['yasmin','shahid'];
let bhuvneshwarCRS = ['kaushik','nisha'];

let CRS =[

   ... mumbaiCRS,
    ...noidaCRS,
    ...bangaloreCRS,
    ... bhuvneshwarCRS,
    'subrat'
]
console.log(CRS);

//de-structuring array

let [name1,name2,name3,...restValues]=CRS;
console.log(name1);
console.log(name2);
console.log(restValues);



 console.log(CRS);
 
 //de-structuring object
 var a, b, rest;
 [a, b] = [10, 20];
 console.log(a); // 10
 console.log(b); // 20
 
