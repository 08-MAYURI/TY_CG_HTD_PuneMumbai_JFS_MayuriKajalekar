let mystring ='Capgemini trainee are really intelligent';

//indexOf it returns true or false

console.log(myString.indexOf('are'));
console.log(myString.includes(train));

//reverse a string

//split method into array
let reversedString =myString.split();
console.log(reversedString);

//split method into single word
let reversedString =myString.split('');
console.log(reversedString);

//reverse the string
let reversedString =myString.split('').reverse().join('');
console.log(reversedString);


//charAt() method
console.log(mystring.charAt(2));

//charCodeAt() method
console.log(mystring.charCodeAt(1));
