var x =[12344, 'xyz', true,{name:'shahrukh khan'}];
console.log(x[3]);

for(var i=0; i < x.length; i++){
    console.log(x[i]);
}

var colors = ['yellow','red','green','black'];
console.log(colors);
colors.pop();
console.log(colors);
colors.push('voilet','blue');
console.log(colors);
colors.shift();
console.log(colors);
colors.unshift('purple','orange');
console.log(colors);
colors.splice(2,2);
console.log(colors);
colors.splice(2,1,'indigo','orange','indian black');
console.log(colors);


// function test(cb){
//     console.log('test function started');
//     cb();
//     console.log('test function ended'); 
// }

// test(function(){
//     console.log('calback function is being executed');
// });

// setTimeout(function()
// {
//     console.log('calback function is being executed');

// },1);

// var
// setInterval(function()
// {
//     console.log(i);
//     i++;

// },1);

// //callback concept
// function test(cb){
//     console.log('test function started');
// }
// console.log(colors.indexOf('black'));

// colors.forEach(function(value,index,array){
//     console.log(value, index , array);
// });

// //filter

// var myArray=[101,102,105,110,120,130,140];
// var newArray = myArray.filter(function(value,index,array){
//     return (value>110);
// });
// console.log(newArray);


// var filteredArray = myArray.filter(function(value,index,array){
//     return array.indexOf(value)===index;
// });
// console.log(filteredArray);

// //==
// if(123=='123')
// {
//     console.log(true);
// }    
// else{
//         console.log(false);
//     }

// // ===
//     if(123==='123')
// {
//     console.log(true);
// }    
// else{
//         console.log(false);
//     }

//  // for-of loop   
// for(var x of myArray)
// {
//     console.log(x);
// }
    
// for-in loop
for(var index in colors){
    console.log("the value is :",colors[index],"and the index is ",index);   
}

var movie={
    name:'Son of satyamurthi',
    actor:'allu arjun',
    actress:'samantha',
    director:'reddy'
}
console.log(movie['name']);

for(var key in movie){
    console.log(key+":"+movie[key]);   
}

