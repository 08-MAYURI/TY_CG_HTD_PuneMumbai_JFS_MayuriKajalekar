//fat-arroe fun
let add = (a,b)=>{
    console.log('sum is:',a+b);
};
add(10,20);

//fat arrow fun(only on argument)

let printAge =age=>{
    console.log("the age is:",age);
}
printAge(12354);

//fat arrow fun with single return statement

let product=(a,b) => a*b;
console.log(product(34,876));
