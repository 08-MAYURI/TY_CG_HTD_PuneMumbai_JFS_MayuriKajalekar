var myString =`Alerts are available for any length of text, 
as well as an optional dismiss button. For proper styling, 
use one of the eight required contextual classes (e.g., .alert-success). 
For inline dismissal, use the alerts jQuery plugin.`

console.log(myString);

var name='kartik';
var role='cr';
var batch ='noida';

console.log(`I am ${name} and I am ${role} of the ${batch} batch`);

console.log(`sum of 1234 and 4321 is ${1234+4321}`);