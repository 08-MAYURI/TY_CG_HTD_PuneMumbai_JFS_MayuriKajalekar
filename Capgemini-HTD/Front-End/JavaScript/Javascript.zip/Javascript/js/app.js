 //prompt('please write your name:')
 var myname = 70970397907;
 myname = "Mayuri";
 console.log(typeof myname);

 var areYouGood = true;
 console.log(typeof areYouGood);
