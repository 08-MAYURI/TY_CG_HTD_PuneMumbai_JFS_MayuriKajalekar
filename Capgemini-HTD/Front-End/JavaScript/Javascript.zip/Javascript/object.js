//literal way of object creation

var student = {
     name :`Shaid afridi`,
     age : 24,
     degree : `BE`,
     phoneNumber : 8798386887
};

//call object
console.log(student.name);

console.log(student);
student.phoneNumber = 88980979078;
console.log(student.phoneNumber);

student.selectedCompany = `capgemini`;
console.log(student);

//object creation using object creation

var laptop = new Object();
laptop.brand = `lenovo`;
laptop.ram = `8GB`;
laptop.processor = `Core i3`;
laptop.price = 29000;

console.log(laptop);
console.log(Object.keys(laptop).length);