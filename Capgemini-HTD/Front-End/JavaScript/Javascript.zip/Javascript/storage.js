localStorage.setItem('name','mayuri');
console.log(localStorage.getItem('name','mayuri'));

localStorage.clear();
console.log(localStorage.getItem);

sessionStorage.setItem('name','mayuri');
console.log(sessionStorage.getItem('name','mayuri'));
