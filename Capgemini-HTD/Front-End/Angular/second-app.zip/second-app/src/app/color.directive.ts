import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[appColor]'
})

export class ColorDirective{

    constructor(private e1: ElementRef){
        this.e1.nativeElement.style.backgroundColor = 'red';
        this.e1.nativeElement.style.color = 'white';
        this.e1.nativeElement.style.padding = '5px';
        //this.e1.nativeElement.style.fontSize ='30px';
    }

    @HostListener('style.fontSize') fontSize;

@HostListener('mouseenter')
mouseEnter()
{
    console.log('mouse entered');
    this.fontSize ='50px';
    this.e1.nativeElement.style.background = 'blue';
}

@HostListener('mouseleave')
mouseLeave()
{
    console.log('mouse left');
    this.fontSize='50px';
    this.e1.nativeElement.style.background = 'black';
}
}