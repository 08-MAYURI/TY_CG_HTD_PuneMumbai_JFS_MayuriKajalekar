import { Component, OnInit } from '@angular/core';
import { Product} from '../product'

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
products:Product[]=[
  {
    name:'MacBook Air',
    imageUrl:'https://cdn.pixabay.com/photo/2014/12/22/19/59/macbook-577758__340.jpg',
    price:60000,
    details:'good quality'
  },
  {
    name:'Smart Phone',
    imageUrl:'https://cdn.pixabay.com/photo/2017/04/26/16/06/mobile-2262928__340.jpg',
    price:25000,
    details:'good quality'
  },
  {
    name:'Washing machine',
    imageUrl:'https://image.shutterstock.com/image-photo/empty-washing-machine-pile-dirty-260nw-566248510.jpg',
    price:20000,
    details:'good quality'
  },
  {
    name:'Air Conditioner',
    imageUrl:'https://cdn.pixabay.com/photo/2019/05/15/10/16/air-conditioner-4204637__340.jpg',
    price:100000,
    details:'good quality'
  },
  {
    name:'Camera',
    imageUrl:'https://cdn.pixabay.com/photo/2014/12/27/15/31/camera-581126__340.jpg',
    price:80000,
    details:'good quality'
  }
]


  constructor() { }

  ngOnInit() {
  }

}
