import { Component, OnInit } from '@angular/core';
import { Bike } from '../bike';

@Component({
  selector: 'app-bike',
  templateUrl: './bike.component.html',
  styleUrls: ['./bike.component.css']
})
export class BikeComponent implements OnInit {

  bikes: Bike[] =[

    {
      brand:'Royal Enfield',
      imgURL:'https://cdn.pixabay.com/photo/2019/05/24/16/38/bullet-ride-4226666__340.jpg',
      model:'classic 350',
      price: 1500000,
      specs:`About Classic 350 Specs and Features. Royal Enfield Classic 350 price starts at Rs.1.46 lakh (Ex-Showroom, Delhi) and the top end variant Royal Enfield Classic 350 Signals Edition is priced at Rs. 1.64 lakh (Ex-Showroom, Delhi).
      Royal Enfield Classic 350 Competitors Mojo 300: `
    },
    {
      brand:'Jawa',
      imgURL:'https://cdn.pixabay.com/photo/2017/10/29/14/13/motorcycle-2899798__340.jpg',
      model:'293cc single-cylinder',
      price: 140000,
      specs:`The motorcycle comes with a 293cc single-cylinder DOHC liquid-cooled engine that complies with BSVI emission norms. It generates 27PS of power and 28Nm of torque and is mated to a six-speed gearbox.
       The motorcycle comes with a double cradle frame`
    },
    {
      brand:'Yamaha',
      imgURL:'https://cdn.pixabay.com/photo/2019/01/20/15/34/motorcycle-3943989__340.jpg',
      model:'R15 YHZ',
      price: 140000,
      specs:`Yamaha YZF R15 V3 price starts at Rs.1.41 lakh (Ex-Showroom, Delhi) and the top end variant Yamaha YZF R15 V3 Moto GP Limited Edition is priced at Rs. 1.43 lakh (Ex-Showroom, Delhi).
       In contrast, R15 v3.0 gets a new and slightly larger 155cc liquid-cooled four-valve motor w`
    }
    
    
  ]
  selectedBike:Bike =this.bikes[0];
  constructor() { }

  selectBike(bike){
   this.selectedBike = bike;
  }

  ngOnInit() {
  }

}
