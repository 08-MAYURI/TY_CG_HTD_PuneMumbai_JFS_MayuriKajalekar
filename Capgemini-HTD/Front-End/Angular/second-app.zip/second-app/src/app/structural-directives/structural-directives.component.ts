import { Component, OnInit } from '@angular/core';
import { Student } from '../student';

@Component({
  selector: 'app-structural-directives',
  templateUrl: './structural-directives.component.html',
  styleUrls: ['./structural-directives.component.css']
})
export class StructuralDirectivesComponent implements OnInit {
  flag=false;
  students: Student[]=[
    {
      id:1234,
      name:'mayuri',
      age:22,
      degree:'BE'
    },
    {
      id:1235,
      name:'Shreyas',
      age:20,
      degree:'BE'
    },
    {
      id:1235,
      name:'Divya',
      age:23,
      degree:'BTech'
    },
    {
      id:1236,
      name:'Virendra',
      age:25,
      degree:'BE'
    },
    {
      id:1237,
      name:'Prajakta',
      age:27,
      degree:'Bsc'
    },
    {
      id:1234,
      name:'Rushikesh',
      age:28,
      degree:'MBA'
    },
  ]
  constructor() { 
   
    setTimeout(() =>{
    this.flag =true;
  },2000);
}

deleteStudent(student:Student)
{
  const index =this.students.indexOf(student);
  this.students.splice(index,1);
}
  ngOnInit() {
  }

}
