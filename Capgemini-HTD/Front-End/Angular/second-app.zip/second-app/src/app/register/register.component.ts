import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { CustomValidator } from './custom.validator';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  constructor() { 
    console.log('constructor get called');
  }
  
  get email(){
    return this.registerForm.get('email');
  }

  get password(){
    return this.registerForm.get('password');
  }
   
  registerForm =new FormGroup({
    email: new FormControl('',[
      Validators.required,
      Validators.email,
      Validators.minLength(8),
      CustomValidator.noSpace
    ]),
    password: new FormControl('',[
      Validators.required,
      Validators.minLength(8)
      
    ])
  });

   printForm(form: NgForm){
     console.log(form.value);
   }

  ngOnInit() {
    console.log('onInit get called');
  }
  ngOnDestroy(){
    console.log("inDestroy get called");
  }

}
