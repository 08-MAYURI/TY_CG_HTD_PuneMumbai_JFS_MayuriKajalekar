import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html',
  styleUrls: ['./binding.component.css']
})
export class BindingComponent implements OnInit {

  name='mayuri';
  imgUrl='https://cdn.pixabay.com/photo/2019/10/14/17/46/garden-4549529__340.jpg';
  flag=true;
    
  constructor() {
    // setTimeout(()=>{
    //   this.flag(true);
    // },5000);
    // }
    setInterval(()=>{
      this.flag=!this.flag;
    },1000);
  }
   
  eventOccured(input)
  {
    console.log(input.value);
    console.log('key up event is occured');
  }

  ngOnInit() {
  }

}
