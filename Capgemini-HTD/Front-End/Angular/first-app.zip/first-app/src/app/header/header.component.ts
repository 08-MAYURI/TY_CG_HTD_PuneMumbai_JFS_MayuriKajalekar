import { Component } from '@angular/core';
import { Template } from '@angular/compiler/src/render3/r3_ast';

@Component({
    selector: 'app-header',
//     template: `<h1>Header Componenet is working</h1>`,
//     styles:[
//         `h1 {
//              background: black,
//              color: white
//             }`
//     ]
templateUrl: './header.component.html',
styleUrls: ['./header.component.css']

})

export class HeaderComponent{

}