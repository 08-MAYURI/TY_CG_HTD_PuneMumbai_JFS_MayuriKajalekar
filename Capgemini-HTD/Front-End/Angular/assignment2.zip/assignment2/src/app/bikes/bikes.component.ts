import { Component, OnInit } from '@angular/core';
import { Bike } from '../bike';

@Component({
  selector: 'app-bikes',
  templateUrl: './bikes.component.html',
  styleUrls: ['./bikes.component.css']
})
export class BikesComponent implements OnInit {

  bikes: Bike[] =[

    {
      name:'Royal Enfield',
      imageUrl:'https://cdn.pixabay.com/photo/2019/05/24/16/38/bullet-ride-4226666__340.jpg',
      model:2015,
      specs:`About Classic 350 Specs and Features. Royal Enfield Classic 350 price starts at Rs.1.46 lakh (Ex-Showroom, Delhi) and the top end variant Royal Enfield Classic 350 Signals Edition is priced at Rs. 1.64 lakh (Ex-Showroom, Delhi).
      Royal Enfield Classic 350 Competitors Mojo 300: `
    },
    {
     name:'Jawa',
      imageUrl:'https://cdn.pixabay.com/photo/2017/10/29/14/13/motorcycle-2899798__340.jpg',
      model:1998,
      specs:`The motorcycle comes with a 293cc single-cylinder DOHC liquid-cooled engine that complies with BSVI emission norms. It generates 27PS of power and 28Nm of torque and is mated to a six-speed gearbox.
       The motorcycle comes with a double cradle frame`
    },
    {
      name:'Yamaha',
      imageUrl:'https://cdn.pixabay.com/photo/2019/01/20/15/34/motorcycle-3943989__340.jpg',
      model:2010,
      specs:`Yamaha YZF R15 V3 price starts at Rs.1.41 lakh (Ex-Showroom, Delhi) and the top end variant Yamaha YZF R15 V3 Moto GP Limited Edition is priced at Rs. 1.43 lakh (Ex-Showroom, Delhi).
       In contrast, R15 v3.0 gets a new and slightly larger 155cc liquid-cooled four-valve motor w`
    },
    {
     name:'BMW',
     imageUrl:'https://cdn.pixabay.com/photo/2017/09/06/17/08/bmw-2722258__340.png',
     model:1945,
     specs:`BMW Offers Sedans, SUV in Segments with Automatic Transmission & Advance Safety Features.
      Check Images, Interior & Exterior Features, Specs, Colours, Available Models and Variants.
      3-Year Comp. Service. 3-Year Comp. Maintenance. Exchange Bonus - ₹75,000.`
    },

    {
      name:'SUZUKI',
      imageUrl:'https://cdn.pixabay.com/photo/2016/01/31/14/58/motor-1171515__340.jpg',
      model:1885,
      specs:`Suzuki Motor Corporation (SMC), a global giant of motorcycle manufacturing is headquartered in Japan.
       It holds major stake in its Indian subsidiary, Suzuki Motorcycle India Private Limited (SMIL). SMIL was set up after 
      Suzuki's re-entry into the Indian two-wheeler market after it severed ties with partner TVS in 2000-01. `
     },
     {
      name:'BAJAJ',
      imageUrl:'https://cdn.pixabay.com/photo/2016/07/25/06/16/bajaj-pulsur-1539973__340.jpg',
      model:2012,
      specs:`Bajaj Pulsar 125 Specifications. Engine CC 124.4 cc. No Of Cylinder 1.
       Max Power 11.8 bhp @ 8500 rpm. Max Torque 11 Nm @ 6500 rpm. Valves Per Cylinder 2.
       Fuel Delivery Carburetor. Cooling System Air Cooled. Starting Mechanism Kick and Self Start.`
     },
     
     {
      name:'KAWASAKI',
      imageUrl:'https://cdn.pixabay.com/photo/2015/12/08/00/24/motorcycle-1081685__340.jpg',
      model:2014,
      specs:`Kawasaki Ninja 300 price starts at Rs.2.98 lakh (Ex-Showroom, Delhi). 
      The Kawasaki Ninja 300 is powered by a 296cc, liquid-cooled, parallel twin engine, 
      which produces 39PS at 11,000rpm and 27Nm at 10,000rpm,
       mated to a 6-speed gearbox.`
     }    
  ]
  selectedBike:Bike =this.bikes[0];
  constructor() { }

  selectBike(bike){
   this.selectedBike = bike;
  }

  ngOnInit() {
  }

}
