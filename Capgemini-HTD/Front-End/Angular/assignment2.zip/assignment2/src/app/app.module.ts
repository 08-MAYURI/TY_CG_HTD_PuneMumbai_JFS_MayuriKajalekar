import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { CarsComponent } from './cars/cars.component';
import { BikesComponent } from './bikes/bikes.component';
import { MoviesComponent } from './movies/movies.component';
import { LaptopsComponent } from './laptops/laptops.component';
import { MobilesComponent } from './mobiles/mobiles.component';
import { HomeComponent } from './home/home.component';
import { BikeDetailsComponent } from './bike-details/bike-details.component';
import { CarDetailsComponent } from './car-details/car-details.component';
import { LaptopDetailsComponent } from './laptop-details/laptop-details.component';
import { MobileDetailsComponent } from './mobile-details/mobile-details.component';
import { MovieDetailsComponent } from './movie-details/movie-details.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CarsComponent,
    BikesComponent,
    MoviesComponent,
    LaptopsComponent,
    MobilesComponent,
    HomeComponent,
    BikeDetailsComponent,
    CarDetailsComponent,
    LaptopDetailsComponent,
    MobileDetailsComponent,
    MovieDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
