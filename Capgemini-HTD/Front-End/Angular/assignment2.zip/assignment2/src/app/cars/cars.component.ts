import { Component, OnInit} from '@angular/core';
import { Car } from '../car';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
  
  export class CarsComponent implements OnInit {
  
    cars: Car[] =[
  
      {
        name:'MARUTHI',
        imageUrl:'https://image.shutterstock.com/image-photo/cars-sale-stock-row-car-260nw-636632101.jpg',
        model:1950,
        specs:`The Maruti Swift has 1 Diesel Engine and 1 Petrol Engine on offer. 
        The Diesel engine is 1248 cc while the Petrol engine is 1197 cc.
        Depending upon the variant and fuel type the Swift has a mileage of 22.0 to 28.4 kmpl.
         The Swift is a 5 seater Hatchback and has a length of 3840mm  `
      },
      {
        name:'SUZUKI',
        imageUrl:'https://cdn.pixabay.com/photo/2019/06/29/09/51/suzuki-sx4-4305877__340.jpg',
        model:2015,
        specs:`The Maruti Swift has 1 Diesel Engine and 1 Petrol Engine on offer.
         The Diesel engine is 1248 cc while the Petrol engine is 1197 cc.
          Depending upon the variant and fuel type the Swift has a mileage of 22.0 to 28.4 kmpl.
         The Swift is a 5 seater Hatchback and has a length of 3840mm  `
      },
      {
        name:'AUDI',
        imageUrl:'https://cdn.pixabay.com/photo/2016/12/03/11/47/car-1879629__340.jpg',
        model:2002,
        specs:` A4 Specs, Features and Price. The Audi A4 has 1 Diesel Engine and 1 Petrol Engine on offer.
         The Diesel engine is 1968 cc while the Petrol engine is 1395 cc.`
      },
      {
        name:'LAMBORGINI',
        imageUrl:'https://cdn.pixabay.com/photo/2019/01/08/01/05/car-3920221__340.jpg',
        model:1980,
        specs:`The Petrol engine is 6498 cc. It is available with the Automatic transmission.
         Depending upon the variant and fuel type the Aventador has a mileage of 5.0 to 7.69 kmpl.
          The Aventador is a 2 seater Coupe and has a length of 4843 mm, 
        width of 2273 mm and a wheelbase of 2700mm. `
      },
      {
        name:'SWIFT',
        imageUrl:'https://cdn.pixabay.com/photo/2017/10/18/19/54/tata-nano-2865322__340.jpg',
        model:1960,
        specs:` The Maruti Swift has 1 Diesel Engine and 1 Petrol Engine on offer.
         The Diesel engine is 1248 cc while the Petrol engine is 1197 cc. 
         It is available with the Manual and Automatic transmission. 
        Depending upon the variant and fuel type the Swift has a mileage of 22.0 to 28.4 kmpl.`
      },
      {
        name:'FERARRI',
        imageUrl:'https://cdn.pixabay.com/photo/2012/02/27/17/08/sportscar-17583__340.jpg',
        model:1960,
        specs:`n Ferrari's first official announcement of the car, 
        the 458 was described as the successor to the F430 but arising from an entirely new design,
         incorporating technologies developed from the company's experience in Formula One.
        The body computer system was developed by Magneti Marelli. `
      },
      {
        name:'MERCEDES BENZ',
        imageUrl:'https://cdn.pixabay.com/photo/2016/06/20/22/32/mercedes-benz-1470115__340.jpg',
        model:1930,
        specs:` The Diesel engine is 2143 cc while the Petrol engine is 1595 cc.
         Depending upon the variant and fuel type the A-Class has a mileage of 15.5 to 20.0 kmpl. 
         The A-Class is a 5 seater Hatchback and has a length of 4299 mm, 
         width of 1780 mm and a wheelbase of 2699 mm. `
      },
      {
        name:'AUDI RS3',
        imageUrl:'https://cdn.pixabay.com/photo/2018/07/23/14/52/audi-3557069__340.jpg',
        model:1860,
        specs:`The 2019 Audi RS 3 features a 2.5-liter TFSI® turbocharged engine that’s known 
        for its unique firing order and inimitable sound, producing 394 horsepower and 354 lb-ft of torque. 
        An even more distinct engine note can be struck through the available Sport exhaust system  `
      }
     
    ];
    selectedCar:Car =this.cars[0];
    constructor() { }
  
    selectCar(car){
     this.selectedCar = car;
    }
  
    ngOnInit() {
    }
  
  }
  
