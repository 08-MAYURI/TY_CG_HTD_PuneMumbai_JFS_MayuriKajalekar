import { Component, OnInit } from '@angular/core';
import { Laptop } from '../laptop';

@Component({
  selector: 'app-laptops',
  templateUrl: './laptops.component.html',
  styleUrls: ['./laptops.component.css']
})
export class LaptopsComponent implements OnInit {
  laptops: Laptop[] =[
  
    {
      name:'LENOVO',
      imageUrl:'https://image.shutterstock.com/image-photo/isolated-laptop-empty-space-on-260nw-613755491.jpg',
      price:35000,
      specs:`he brains of the laptop, the better the processor, the faster your computer will run. For a dependable laptop, an Intel i3 is fine, but an i5 will guarantee good speeds. 
      Laptops with i7 chips cost a lot more, and are more suited to those running design software or games. `
    },
   
    {
      name:'DELL',
      imageUrl:'https://cdn.pixabay.com/photo/2017/03/14/20/39/dell-2144351__340.jpg',
      price:43000,
      specs:` he brains of the laptop, the better the processor, the faster your computer will run.
      For a dependable laptop, an Intel i3 is fine, but an i5 will guarantee good speeds. 
     Laptops with i7 chips cost a lot more, and are more suited to those running design software or games.`
    },

    {
      name:'ACER',
      imageUrl:'https://cdn.pixabay.com/photo/2015/05/31/12/45/laptop-791558__340.jpg',
      price:23000,
      specs:`he brains of the laptop, the better the processor, the faster your computer will run.
      For a dependable laptop, an Intel i3 is fine, but an i5 will guarantee good speeds. 
     Laptops with i7 chips cost a lot more, and are more suited to those running design software or games. `
    },
    {
      name:'HP',
      imageUrl:'https://cdn.pixabay.com/photo/2016/08/09/22/12/tablet-1581944__340.jpg',
      price:65000,
      specs:` he brains of the laptop, the better the processor, the faster your computer will run.
      For a dependable laptop, an Intel i3 is fine, but an i5 will guarantee good speeds. 
     Laptops with i7 chips cost a lot more, and are more suited to those running design software or games.`
    },
    {
      name:'APPLE',
      imageUrl:'https://cdn.pixabay.com/photo/2014/05/02/21/50/home-office-336377__340.jpg',
      price:100000,
      specs:` he brains of the laptop, the better the processor, the faster your computer will run.
      For a dependable laptop, an Intel i3 is fine, but an i5 will guarantee good speeds. 
     Laptops with i7 chips cost a lot more, and are more suited to those running design software or games.`
    },
    {
      name:'TOSHIBA',
      imageUrl:'https://image.shutterstock.com/image-photo/laptop-blank-screen-on-table-260nw-340152863.jpg',
      price:45000,
      specs:`he brains of the laptop, the better the processor, the faster your computer will run.
      For a dependable laptop, an Intel i3 is fine, but an i5 will guarantee good speeds. 
     Laptops with i7 chips cost a lot more, and are more suited to those running design software or games. `
    },
    {
      name:'SONY',
      imageUrl:'https://image.shutterstock.com/image-photo/successful-female-grapic-designer-watching-260nw-1033103851.jpg',
      price:1020000,
      specs:` he brains of the laptop, the better the processor, the faster your computer will run.
       For a dependable laptop, an Intel i3 is fine, but an i5 will guarantee good speeds. 
      Laptops with i7 chips cost a lot more, and are more suited to those running design software or games.`
    }
   
    
  ];
  constructor() { }

  selectedLaptop:Laptop =this.laptops[0];
  
  selectLaptop(laptop){
     this.selectedLaptop = laptop;
  }

  ngOnInit() {
  }

}
