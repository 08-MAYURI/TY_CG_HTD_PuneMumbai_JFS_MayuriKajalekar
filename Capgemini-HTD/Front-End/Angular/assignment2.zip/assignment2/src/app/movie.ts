export class Movie {
    constructor(
        public name: string,
        public imageUrl: string,
        public specs: string
    ){}
}
