export class Laptop {
    constructor(
        public name: string,
        public imageUrl: string,
        public price: number,
        public specs: string
    ){}

}
