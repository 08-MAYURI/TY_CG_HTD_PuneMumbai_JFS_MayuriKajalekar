import { Component, OnInit } from '@angular/core';
import { Movie } from '../movie';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {

 movies: Movie[] =[
  {
        name:'Zindagi Na Milegi Dobara',
        imageUrl:'https://cdn.pixabay.com/photo/2015/03/19/23/03/divers-681516__340.jpg',
        specs:`Friends Kabir, Imran and Arjun take a vacation in Spain before Kabir's marriage.
         The trip turns into an opportunity to mend fences, heal wounds, 
        fall in love with life and combat their worst fears`
  }, 
  {
    name:'Life Of Pi',
    imageUrl:'https://cdn.pixabay.com/photo/2015/03/26/05/54/diving-689825__340.jpg',
    specs:`Pi Patel finds a way to survive in a lifeboat that is adrift in the middle of nowhere. 
    His fight against the odds is heightened by the company of a hyena and a male Bengal tiger.`
}, 
{
  name:'Avenger',
  imageUrl:'https://cdn.pixabay.com/photo/2019/05/10/18/21/thanos-4194122__340.png',
  specs:`S.H.I.E.L.D. leader Nick Fury is compelled to launch the Avengers Initiative 
  when Loki poses a threat to planet Earth. His squad of superheroes put their minds together
   to accomplish the task.`
}, 
{
  name:'Mission Impossible',
  imageUrl:'https://cdn.pixabay.com/photo/2017/09/14/07/05/monument-valley-2748148__340.jpg',
  specs:`Mission: Impossible is a series of American action spy films both based on and 
  a follow-on from the television series of the same name created by Bruce Geller.
   The series is co-produced by and stars Tom Cruise,
   whose character is Ethan Hunt, an agent of the Impossible Missions Force`
}, 
{
  name:'IT',
  imageUrl:'https://cdn.pixabay.com/photo/2018/01/29/19/00/park-3116883__340.jpg',
  specs:`Defeated by members of the Losers' Club, the evil clown Pennywise returns 27 years 
  later to terrorize the town of Derry, Maine, once again. Now adults, 
  the childhood friends have long since gone their separate ways.
   But when people start disappearing, Mike Hanlon calls the others home for one final `
}, 
{
  name:'Vision',
  imageUrl:'https://cdn.pixabay.com/photo/2015/03/26/10/24/eye-691269__340.jpg',
  specs:`A French woman traveling through the forests of Japan recalls the first romance of her life.`
}, 
{
  name:'Pirates Of Carabian',
  imageUrl:'https://cdn.pixabay.com/photo/2017/04/04/19/47/ship-2202910__340.jpg',
  specs:`It is a series of five fantasy swashbuckler films 
  produced by Jerry Bruckheimer and loosely based on Walt Disney's eponymous theme park ride. 
  Directors of the series include Gore Verbinski, 
  Rob Marshall and Joachim Rønning and Espen Sandberg.`
}, 
{
  name:'Race',
  imageUrl:'',
  specs:`Race is a series of Indian action-thriller films. 
  The series is directed by Abbas-Mustan, Remo D'Souza and produced by Ramesh S. Taurani, Kumar S. Taurani and 
  Salman Khan under the banner of Tips Industries and Salman Khan Films.`
} 

  
  ];
  selectedMovie:Movie =this.movies[0];
  constructor() { }

  selectMovie(movie){
   this.selectedMovie = movie;
  }

  ngOnInit() {
  }

}