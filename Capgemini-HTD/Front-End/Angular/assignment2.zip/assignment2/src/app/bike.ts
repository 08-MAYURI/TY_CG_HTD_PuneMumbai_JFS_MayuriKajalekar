export class Bike {
    constructor(
            public name: string,
            public imageUrl: string,
            public model: number,
            public specs: string
        ){}
    
}

