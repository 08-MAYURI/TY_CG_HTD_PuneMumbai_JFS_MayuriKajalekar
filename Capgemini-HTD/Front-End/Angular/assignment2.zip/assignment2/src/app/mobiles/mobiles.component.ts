import { Component, OnInit ,Input} from '@angular/core';
import { Mobile } from '../mobile';

@Component({
  selector: 'app-mobiles',
  templateUrl: './mobiles.component.html',
  styleUrls: ['./mobiles.component.css']
})
export class MobilesComponent implements OnInit {
 mobiles: Mobile[] =[
  
  {
    name:'LENOVO',
    imageUrl:'https://cdn.pixabay.com/photo/2015/08/07/00/34/lenovo-878838__340.jpg',
    price:15000,
    specs:`MOLED, LCD, Super LCD, Retina, PPI, ClearBlack. What you need to know: 
    Bigger displays might look better but also drain battery life. 
    And while we recommend going for the highest resolution screen within your budget, 
    do remember to check if the apps you want to use support that resolution. 
    As for the AMOLED vs LCD debate, we advise you to trust your eyes to 'see' which one works best for you.
     As a general rule, 
    AMOLEDs are brighter and produce richer colours, but LCDs render text better. `
  },
  {
    name:'XIOMI',
    imageUrl:'https://image.shutterstock.com/image-vector/smartphone-mobile-phone-isolated-realistic-260nw-703670326.jpg',
    price:25000,
    specs:`MOLED, LCD, Super LCD, Retina, PPI, ClearBlack. What you need to know: 
    Bigger displays might look better but also drain battery life. 
    And while we recommend going for the highest resolution screen within your budget, 
    do remember to check if the apps you want to use support that resolution. 
    As for the AMOLED vs LCD debate, we advise you to trust your eyes to 'see' which one works best for you.
     As a general rule, 
    AMOLEDs are brighter and produce richer colours, but LCDs render text better. `
  },
  {
    name:'APPLE',
    imageUrl:'https://cdn.pixabay.com/photo/2017/01/06/13/50/smartphone-1957741__340.jpg',
    price:60000,
    specs:`MOLED, LCD, Super LCD, Retina, PPI, ClearBlack. What you need to know: 
    Bigger displays might look better but also drain battery life. 
    And while we recommend going for the highest resolution screen within your budget, 
    do remember to check if the apps you want to use support that resolution. 
    As for the AMOLED vs LCD debate, we advise you to trust your eyes to 'see' which one works best for you.
     As a general rule, 
    AMOLEDs are brighter and produce richer colours, but LCDs render text better.`
  },
  {
    name:'SAMSUNG',
    imageUrl:'https://cdn.pixabay.com/photo/2017/04/26/16/06/mobile-2262928__340.jpg',
    price:35000,
    specs:`MOLED, LCD, Super LCD, Retina, PPI, ClearBlack. What you need to know: 
    Bigger displays might look better but also drain battery life. 
    And while we recommend going for the highest resolution screen within your budget, 
    do remember to check if the apps you want to use support that resolution. 
    As for the AMOLED vs LCD debate, we advise you to trust your eyes to 'see' which one works best for you.
     As a general rule, 
    AMOLEDs are brighter and produce richer colours, but LCDs render text better. `
  },
  {
    name:'MOTOROLO',
    imageUrl:'https://cdn.pixabay.com/photo/2017/08/06/18/16/mobile-2594848__340.jpg',
    price:10000,
    specs:` MOLED, LCD, Super LCD, Retina, PPI, ClearBlack. What you need to know: 
    Bigger displays might look better but also drain battery life. 
    And while we recommend going for the highest resolution screen within your budget, 
    do remember to check if the apps you want to use support that resolution. 
    As for the AMOLED vs LCD debate, we advise you to trust your eyes to 'see' which one works best for you.
     As a general rule, 
    AMOLEDs are brighter and produce richer colours, but LCDs render text better.`
  },
  {
    name:'NOKIA',
    imageUrl:'https://cdn.pixabay.com/photo/2015/09/06/00/50/nokia-926756__340.jpg',
    price:65000,
    specs:` MOLED, LCD, Super LCD, Retina, PPI, ClearBlack. What you need to know: 
    Bigger displays might look better but also drain battery life. 
    And while we recommend going for the highest resolution screen within your budget, 
    do remember to check if the apps you want to use support that resolution. 
    As for the AMOLED vs LCD debate, we advise you to trust your eyes to 'see' which one works best for you.
     As a general rule, 
    AMOLEDs are brighter and produce richer colours, but LCDs render text better.`
  },
  {
    name:'OPPO',
    imageUrl:'https://cdn.pixabay.com/photo/2019/08/22/12/09/coffee-4423348__340.jpg',
    price:16000,
    specs:`MOLED, LCD, Super LCD, Retina, PPI, ClearBlack. What you need to know: 
    Bigger displays might look better but also drain battery life. 
    And while we recommend going for the highest resolution screen within your budget, 
    do remember to check if the apps you want to use support that resolution. 
    As for the AMOLED vs LCD debate, we advise you to trust your eyes to 'see' which one works best for you.
     As a general rule, 
    AMOLEDs are brighter and produce richer colours, but LCDs render text better. `
  },
  {
    name:'VIVO',
    imageUrl:'https://cdn.pixabay.com/photo/2017/01/06/13/50/smartphone-1957742__340.jpg',
    price:20000,
    specs:`MOLED, LCD, Super LCD, Retina, PPI, ClearBlack. What you need to know: 
    Bigger displays might look better but also drain battery life. 
    And while we recommend going for the highest resolution screen within your budget, 
    do remember to check if the apps you want to use support that resolution. 
    As for the AMOLED vs LCD debate, we advise you to trust your eyes to 'see' which one works best for you.
     As a general rule, 
    AMOLEDs are brighter and produce richer colours, but LCDs render text better. `
  },
  {
    name:'LAVA',
    imageUrl:'https://cdn.pixabay.com/photo/2016/11/29/12/30/android-1869510__340.jpg',
    price:21000,
    specs:` MOLED, LCD, Super LCD, Retina, PPI, ClearBlack. What you need to know: 
    Bigger displays might look better but also drain battery life. 
    And while we recommend going for the highest resolution screen within your budget, 
    do remember to check if the apps you want to use support that resolution. 
    As for the AMOLED vs LCD debate, we advise you to trust your eyes to 'see' which one works best for you.
     As a general rule, 
    AMOLEDs are brighter and produce richer colours, but LCDs render text better.`
  }
  ];
  selectedMobile:Mobile =this.mobiles[0];
  constructor() { }

  selectMobile(mobiles){
   this.selectedMobile = mobiles;
  }

  ngOnInit() {
  }

}
