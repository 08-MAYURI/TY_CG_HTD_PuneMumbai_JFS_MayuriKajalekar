export class Product {
    constructor(
    public name: String,
    public price:number,
    public url: String,
    public pk ?:string
){}
}