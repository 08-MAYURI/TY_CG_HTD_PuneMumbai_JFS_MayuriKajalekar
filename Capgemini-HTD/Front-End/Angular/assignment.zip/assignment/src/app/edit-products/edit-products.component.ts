import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { NgForm } from '@angular/forms';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-edit-products',
  templateUrl: './edit-products.component.html',
  styleUrls: ['./edit-products.component.css']
})
export class EditProductsComponent implements OnInit {

  selectedProduct: Product = {
    url:null,
    name: null,
    price: null,
    pk: null
  };

  constructor(public productService: ProductService) {
    this.productService.getData();
  }

  deleteProduct(product: Product) {
    this.productService.deleteData(product).subscribe(response => {
      console.log(response);
      console.log('deleted one employee');
      //  to update the table again
      this.productService.getData();
    }, err => {
      console.log(err);

    });
  }

  selectProduct(product: Product) {
    this.selectedProduct= product;
  }

  submitForm(form: NgForm) {
    this.productService.putData(form.value).subscribe(response => {
      console.log(response);
      form.reset();
    }, err => {
      console.log(err);

    });
  }

  ngOnInit() {
  }

}
