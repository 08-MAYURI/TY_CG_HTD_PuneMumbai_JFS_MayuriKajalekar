package com.capgemini.annotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.capgemini.annotations.bean.Pet;

@Import(AnimalConfig.class)
@Configuration
public class PetConfig {
	
	@Bean
	public Pet getpet() {
		Pet mypet = new Pet();
		mypet.setName("Rocky");
		return mypet;
	}//end of getPet()
}//end of class
