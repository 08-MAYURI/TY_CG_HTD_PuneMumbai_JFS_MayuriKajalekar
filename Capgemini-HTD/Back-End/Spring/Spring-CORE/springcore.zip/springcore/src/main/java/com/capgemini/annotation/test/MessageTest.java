package com.capgemini.annotation.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.capgemini.annotation.config.MessageConfig;
import com.capgemini.annotations.bean.MessageBean;

public class MessageTest {

	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(MessageConfig.class);
		// messagebean 1 
		MessageBean messageBean = context.getBean(MessageBean.class);
		
		System.out.println("Message Bean 1  = "+messageBean.getMessage());
		// messagebean 2
		MessageBean messageBean2 = context.getBean(MessageBean.class);
		System.out.println("..........................................");
		System.out.println("Message Bean 2  = "+messageBean2.getMessage());
		// set new message
		messageBean2.setMessage("new message");
		// printing messagebean1 and messagebean2
		System.out.println("...........................................");
		System.out.println("Message Bean 1  = "+messageBean.getMessage());
		System.out.println("............................................");
		System.out.println("Message Bean 2  = "+messageBean2.getMessage());

	}// End of Main()

}// End of Class
