package com.capgemini.springcore;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.EmployeeBean;

public class EmployeeTest2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ApplicationContext context = new ClassPathXmlApplicationContext("employeeConfig.xml");
		EmployeeBean eb = (EmployeeBean) context.getBean("employee");
		EmployeeBean eb2 = (EmployeeBean) context.getBean("employee");
//		System.out.println("enter how many employee you want to add");
//		int a = Integer.parseInt(sc.nextLine());
//		
//		for (int i = 1; i <= a; i++) {
			System.out.println("Enter your ID");
			eb.setEmpId(Integer.parseInt(sc.nextLine()));

			System.out.println("enter your name");
			eb.setEmpName(sc.nextLine());
			
			System.out.println("Enter your ID");
			eb2.setEmpId(Integer.parseInt(sc.nextLine()));

			System.out.println("enter your name");
			eb2.setEmpName(sc.nextLine());
//		}
//		
//		for (int i = 1; i <= a; i++) {
			System.out.println("employee Id = " + eb.getEmpId());
			System.out.println("employee name = " + eb.getEmpName());
			
			System.out.println("employee Id = " + eb2.getEmpId());
			System.out.println("employee name = " + eb2.getEmpName());
//		}
	}
}
