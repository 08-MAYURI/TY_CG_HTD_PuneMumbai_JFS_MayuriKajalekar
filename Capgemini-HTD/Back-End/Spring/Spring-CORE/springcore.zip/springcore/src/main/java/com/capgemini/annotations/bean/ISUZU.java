package com.capgemini.annotations.bean;

import com.capgemini.springcore.interfaces.Engine;

public class ISUZU implements Engine{

	@Override
	public double getCC() {
		return 4125;
	}

	@Override
	public String getType() {
		return "4-stroke petrol";
	}
	
}
