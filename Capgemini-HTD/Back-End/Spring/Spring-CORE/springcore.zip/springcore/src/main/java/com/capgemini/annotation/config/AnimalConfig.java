package com.capgemini.annotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

import com.capgemini.annotations.bean.DOg;
import com.capgemini.annotations.bean.Panda;

public class AnimalConfig {
	
	@Bean(name = "dog")
	public DOg getDog() {
		return new DOg();
	}//end of getDog
	
	@Bean(name = "panda")
	@Primary
	public Panda getPanda() {
		return new Panda();
	}// end of getPanda()
}// end of class
