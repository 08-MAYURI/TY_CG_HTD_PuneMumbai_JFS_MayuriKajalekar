package com.capgemini.annotation.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.capgemini.annotation.config.DepartMentConfig;
import com.capgemini.annotation.config.EmloyeeConfig;

import com.capgemini.annotations.bean.EmployeeBean;

public class EmployeeTest {
	
	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(EmloyeeConfig.class);
		EmployeeBean employeeBean = context.getBean(EmployeeBean.class);
		System.out.println("............................................");
		System.out.println("Employee ID = "+ employeeBean.getEmpId());
		System.out.println("Employee Name = "+ employeeBean.getEmpName());
		System.out.println("............................................");
		System.out.println("Department ID = "+ employeeBean.getDepartmentBean().getDeptId());
		System.out.println("Department Name = "+ employeeBean.getDepartmentBean().getDeptName());
		System.out.println("............................................");
		//((AbstractApplicationContext)context).registerShutdownHook();
		((AbstractApplicationContext)context).close();
	}// end of main

}// end of class
