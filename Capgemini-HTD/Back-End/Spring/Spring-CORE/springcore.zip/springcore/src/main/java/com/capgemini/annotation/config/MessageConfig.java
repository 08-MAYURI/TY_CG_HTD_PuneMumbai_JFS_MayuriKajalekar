package com.capgemini.annotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.capgemini.annotations.bean.MessageBean;

@Configuration
public class MessageConfig {
	
	@Bean
	@Scope("prototype")
	public MessageBean getMessageBean() {
		MessageBean messageBean = new MessageBean();
		messageBean.setMessage("Hello");
		return messageBean;
	}

}// End of Class
