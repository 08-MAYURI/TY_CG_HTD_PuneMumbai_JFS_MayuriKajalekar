package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.MedicineBean;
import com.capgemini.springcore.beans.SportsBean;

public class SportsTest {
	public static void main(String[] args) {
	ApplicationContext context = new ClassPathXmlApplicationContext("sportsConfig.xml");
		
		System.out.println("Map....................................................");
		SportsBean sportsBean = (SportsBean) context.getBean("sportsMap");

		System.out.println("medicine name = " + sportsBean.getName());
		System.out.println("medicine price  = " + sportsBean.getTotalPlayers());
		System.out.println("medicine type  = " + sportsBean.getTeamInfo());
	
	}
}
