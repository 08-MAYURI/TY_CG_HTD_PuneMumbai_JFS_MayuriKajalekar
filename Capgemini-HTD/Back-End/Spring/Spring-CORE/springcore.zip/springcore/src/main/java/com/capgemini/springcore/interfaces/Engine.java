package com.capgemini.springcore.interfaces;

public interface Engine {
	public double getCC();

	public String getType();
}// end of interface
