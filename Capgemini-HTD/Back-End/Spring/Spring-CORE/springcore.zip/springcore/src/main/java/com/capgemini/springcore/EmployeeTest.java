package com.capgemini.springcore;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.EmployeeBean;

public class EmployeeTest {
	public static void main(String[] args) {
		//Scanner sc = new Scanner(System.in);
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		EmployeeBean eb = (EmployeeBean) context.getBean("employeebean");
		EmployeeBean eb2 = context.getBean("employeebean2",EmployeeBean.class);
		System.out.println("employee Id = "+eb.getEmpId());
		System.out.println("employee name = "+eb.getEmpName());
		System.out.println("employee Id = "+eb2.getEmpId());
		System.out.println("employee name = "+eb2.getEmpName());
		
	}//end of main()

}//end of class
