package com.capgemini.annotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capgemini.annotations.bean.DepartmentBean;

@Configuration
public class DepartMentConfig {

	@Bean(name = "Dev")
	public DepartmentBean getDepartmentBean() {
		DepartmentBean departmentBean = new DepartmentBean();
		departmentBean.setDeptId(201);
		departmentBean.setDeptName("Dev");
		return departmentBean;
		
	}
	
	@Bean(name = "Testing")
	//@Primary
	public DepartmentBean getDepartmentBean1() {
		DepartmentBean departmentBean1 = new DepartmentBean();
		departmentBean1.setDeptId(202);
		departmentBean1.setDeptName("Testing");
		return departmentBean1;
		
	}
	@Bean(name = "HR")
	public DepartmentBean getDepartmentBean2() {
		DepartmentBean departmentBean2 = new DepartmentBean();
		departmentBean2.setDeptId(203);
		departmentBean2.setDeptName("HRs");
		return departmentBean2;
		
	}


}
