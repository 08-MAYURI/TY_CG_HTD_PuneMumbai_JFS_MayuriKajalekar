package com.capgemini.annotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.capgemini.annotations.bean.ISUZU;
import com.capgemini.annotations.bean.VW;
import com.capgemini.springcore.interfaces.Engine;

@Configuration
public class EngineConfig {

	@Bean(name = "Isuzu")
	@Primary
	public Engine getIsuzu() {
		return new ISUZU();
	}

	@Bean(name = "Vw")
	public Engine getVw() {
		return new VW();
	}

}// end of class
