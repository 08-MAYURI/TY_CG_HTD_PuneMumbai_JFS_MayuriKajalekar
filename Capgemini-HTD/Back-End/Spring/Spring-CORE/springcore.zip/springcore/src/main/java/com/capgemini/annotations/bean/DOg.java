package com.capgemini.annotations.bean;

import com.capgemini.springcore.interfaces.Animal;

public class DOg implements Animal{
	
	@Override
	public void eat() {
		System.out.println("dog eat()");
	}

	@Override
	public void speak() {
		System.out.println("dog speak()");
	}

	@Override
	public void walk() {
		System.out.println("dog walk()");
	}

}
