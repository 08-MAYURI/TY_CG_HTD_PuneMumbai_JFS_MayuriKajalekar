package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.Mobile;

public class MobileTest {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("mobile.xml");
		System.out.println("..............................................");
		System.out.println("Using By Type");
		Mobile mobile = (Mobile) context.getBean("mobile");
		System.out.println("..............................................");
		System.out.println("Mobile Brand Name  = " + mobile.getBrandName());
		System.out.println("Mobile Model Name = " + mobile.getModelName());
		System.out.println("Mobile Perice = " + mobile.getPrice());
		System.out.println("Mobile Size  = " + mobile.getMobileDisplay().getSize());
		System.out.println("Mobile resolution  = " + mobile.getMobileDisplay().getResolution());
		
		System.out.println("..............................................");
		System.out.println("Using By Name");
		Mobile mobile2 = (Mobile) context.getBean("mobile2");
		System.out.println("..............................................");
		System.out.println("Mobile Brand Name  = " + mobile2.getBrandName());
		System.out.println("Mobile Model Name = " + mobile2.getModelName());
		System.out.println("Mobile Perice = " + mobile2.getPrice());
		System.out.println("Mobile Size  = " + mobile2.getMobileDisplay().getSize());
		System.out.println("Mobile resolution  = " + mobile2.getMobileDisplay().getResolution());

		System.out.println("..............................................");
		System.out.println("Using By Ref");
		Mobile mobile3 = (Mobile) context.getBean("mobile3");
		System.out.println("..............................................");
		System.out.println("Mobile Brand Name  = " + mobile3.getBrandName());
		System.out.println("Mobile Model Name = " + mobile3.getModelName());
		System.out.println("Mobile Perice = " + mobile3.getPrice());
		System.out.println("Mobile Size  = " + mobile3.getMobileDisplay().getSize());
		System.out.println("Mobile resolution  = " + mobile3.getMobileDisplay().getResolution());

		System.out.println("..............................................");
//		System.out.println("Using By constructor");
//		Mobile mobile4 = (Mobile) context.getBean("mobile4");
//		System.out.println("..............................................");
//		System.out.println("Mobile Brand Name  = " + mobile4.getBrandName());
//		System.out.println("Mobile Model Name = " + mobile4.getModelName());
//		System.out.println("Mobile Perice = " + mobile4.getPrice());
//		System.out.println("Mobile Size  = " + mobile4.getMobileDisplay().getSize());
//		System.out.println("Mobile resolution  = " + mobile4.getMobileDisplay().getResolution());

	}// end of main()

}//end of class
