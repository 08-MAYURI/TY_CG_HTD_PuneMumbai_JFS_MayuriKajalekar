package com.capgemini.springcore.beans;

public class Mobile {

	private String brandName;
	private String modelName;
	private int price;
	
	private MobileDisplay mobileDisplay;

	
//	public Mobile(String brandName, String modelName, int price, MobileDisplay mobileDisplay) {
//	
//		this.brandName = brandName;
//		this.modelName = modelName;
//		this.price = price;
//		this.mobileDisplay = mobileDisplay;
//	}

	//getter setter method
	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public MobileDisplay getMobileDisplay() {
		return mobileDisplay;
	}

	public void setMobileDisplay(MobileDisplay mobileDisplay) {
		this.mobileDisplay = mobileDisplay;
	}
	
	
}//end of class
