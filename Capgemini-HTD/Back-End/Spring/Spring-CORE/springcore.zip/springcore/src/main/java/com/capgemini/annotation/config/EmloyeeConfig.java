package com.capgemini.annotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import com.capgemini.annotations.bean.DepartmentBean;
import com.capgemini.annotations.bean.EmployeeBean;

@Import(DepartMentConfig.class)
@Configuration
public class EmloyeeConfig {
	
	@Bean
	public EmployeeBean getEmployeeBean() {
		EmployeeBean employeeBean = new EmployeeBean();
		employeeBean.setEmpId(101);
		employeeBean.setEmpName("Aishwarya");
		return employeeBean;
	}// end of method()
}// end of class
