package com.capgemini.springcore.beans;

public class MobileDisplay {
	
	private int size;
	private int resolution;
	
	//getter setter method
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public int getResolution() {
		return resolution;
	}
	public void setResolution(int resolution) {
		this.resolution = resolution;
	}
	

}//end of class
