package com.capgemini.annotation.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.capgemini.annotation.config.PetConfig;
import com.capgemini.annotations.bean.Pet;

public class AnimalTest {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(PetConfig.class);
		Pet pet = context.getBean(Pet.class);
		System.out.println("Pet Name = "+pet.getName());
		pet.getAnimal().eat();
		pet.getAnimal().walk();
		pet.getAnimal().speak();
	
	
	}// end of main()

}// end of class
