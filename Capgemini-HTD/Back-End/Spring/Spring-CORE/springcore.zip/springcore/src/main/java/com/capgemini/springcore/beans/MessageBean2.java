package com.capgemini.springcore.beans;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class MessageBean2 {
	
	private String message;
	
	// Constructor
	public MessageBean2() {
		System.out.println("Inside Constructor");
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void Init() {
		System.out.println("its init phase");
	}
	
	public void destroy() {
		System.out.println("its destroy phase");
	}
	

}//End of class
