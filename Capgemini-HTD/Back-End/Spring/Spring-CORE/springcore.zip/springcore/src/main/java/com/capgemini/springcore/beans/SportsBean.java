package com.capgemini.springcore.beans;

import java.util.Map;

public class SportsBean {

	private String name;
	private int totalPlayers;
	private Map<String, String> teamInfo;
	
	//getter and setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTotalPlayers() {
		return totalPlayers;
	}
	public void setTotalPlayers(int totalPlayers) {
		this.totalPlayers = totalPlayers;
	}
	public Map<String, String> getTeamInfo() {
		return teamInfo;
	}
	public void setTeamInfo(Map<String, String> teamInfo) {
		this.teamInfo = teamInfo;
	}
	
}// end of class
