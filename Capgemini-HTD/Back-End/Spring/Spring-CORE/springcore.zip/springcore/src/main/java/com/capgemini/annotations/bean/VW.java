package com.capgemini.annotations.bean;

import com.capgemini.springcore.interfaces.Engine;

public class VW implements Engine{

	@Override
	public double getCC() {
		return 1215;
	}

	@Override
	public String getType() {
		return "4-stroke decel";
	}

}
