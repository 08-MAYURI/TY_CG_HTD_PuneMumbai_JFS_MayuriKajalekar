package com.capgemini.annotation.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.annotations.bean.Car;

public class CarTest {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("carConfig.xml");
		Car mycar = context.getBean("mycar",Car.class);
		
		System.out.println("Model name = "+ mycar.getModelName());
		System.out.println("Model no = "+ mycar.getModelNo());
		System.out.println("engine details");
		System.out.println("CC"+ mycar.getEngine().getCC());
		System.out.println("CC"+ mycar.getEngine().getType());
	}//end of main()
}// end of class
