package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.MedicineBean;

public class MedicineTest {
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("medicineConfig.xml");
		
		System.out.println("List....................................................");
		MedicineBean medicineBean = (MedicineBean) context.getBean("medicineList");

		System.out.println("medicine name = " + medicineBean.getName());
		System.out.println("medicine price  = " + medicineBean.getPrice());
		System.out.println("medicine type  = " + medicineBean.getType());
		System.out.println("drugs contains  = " + medicineBean.getDrugs());
		
		System.out.println("Set......................................................");
		MedicineBean medicineBeanSet = (MedicineBean) context.getBean("medicineSet");

		System.out.println("medicine name = " + medicineBeanSet.getName());
		System.out.println("medicine price  = " + medicineBeanSet.getPrice());
		System.out.println("medicine type  = " + medicineBeanSet.getType());
		System.out.println("drugs contains  = " + medicineBeanSet.getDrugsSet());
		

	}
}// end of class
