package com.capgemini.annotations.bean;

public class MessageBean {
	
	// variable declaration
	private String message;

	// Getter and Setter Method
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}// end of class
