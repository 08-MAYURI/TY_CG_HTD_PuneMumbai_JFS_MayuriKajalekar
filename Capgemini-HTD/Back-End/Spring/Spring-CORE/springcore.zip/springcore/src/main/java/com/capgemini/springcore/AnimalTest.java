package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.Pet;


public class AnimalTest {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("petConfig.xml");
		Pet mypet = (Pet) context.getBean("pet");
		mypet.getAnimal().walk();
		mypet.getAnimal().speak();;
		mypet.getAnimal().eat();
	}//end of main

}//end of class
