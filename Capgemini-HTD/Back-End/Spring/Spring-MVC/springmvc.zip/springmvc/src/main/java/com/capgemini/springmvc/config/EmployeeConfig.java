package com.capgemini.springmvc.config;

import org.springframework.context.annotation.Bean;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.stereotype.Component;

@Component
public class EmployeeConfig {
	@Bean
	public LocalEntityManagerFactoryBean getEMP() {
		LocalEntityManagerFactoryBean factoryBean = new LocalEntityManagerFactoryBean();
		factoryBean.setPersistenceUnitName("EmployeePersistanceUnit");
		return factoryBean;
		
	}// end of getImp
	
}// end of claass

