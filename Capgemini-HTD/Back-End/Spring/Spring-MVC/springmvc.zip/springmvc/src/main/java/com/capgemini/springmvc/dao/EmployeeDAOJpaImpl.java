package com.capgemini.springmvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.capgemini.springmvc.bean.EmployeeInfoBean;

@Repository
public class EmployeeDAOJpaImpl implements EmployeeDAO {
	@PersistenceUnit
	private EntityManagerFactory emf;

	@Override
	public EmployeeInfoBean getEmp(int empId) {
		EntityManager em = emf.createEntityManager();
		EmployeeInfoBean emib = em.find(EmployeeInfoBean.class, empId);
		em.close();
		return emib;
	}// end_of_getRmplyee

	@Override
	public EmployeeInfoBean authenticate(int empId, String password) {
		EntityManager em = emf.createEntityManager();
		String jpql = "from EmployeeInfoBean where empId = :empId and password = :password";
		Query q = em.createQuery(jpql);
		q.setParameter("empId", empId);
		q.setParameter("password", password);
		EmployeeInfoBean eib = null;
		try {
			eib = (EmployeeInfoBean) q.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return eib;

	}// end_of_authenticate

	@Override
	public boolean addEmployee(EmployeeInfoBean eib) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		boolean isAdded = false;
		try {
			et.begin();
			em.persist(eib);
			et.commit();
			isAdded = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();
		return isAdded;
	}

	@Override
	public boolean updateEmployee(EmployeeInfoBean eib) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		EmployeeInfoBean eib2 = em.find(EmployeeInfoBean.class, eib.getEmpId());
		if (eib2 != null) {

			if (eib.getEmpName() != null) {
				eib2.setEmpName(eib.getEmpName());
			}
			if (eib.getDesignation() != null) {
				eib2.setDesignation(eib.getDesignation());
			}
			if (eib.getAge() != 0) {
				eib2.setAge(eib.getAge());
			}
			if (eib.getMobile() != 0) {
				eib2.setMobile(eib.getMobile());
			}
			if (eib.getSalry() != 0) {
				eib2.setSalry(eib.getSalry());
			}

		}
		boolean isUpdate = false;
		try {
			et.begin();
			em.persist(eib2);
			et.commit();

			isUpdate = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		em.close();

		return isUpdate;
	}// end of update
	
	@Override
	public boolean deleteEmployee(int empId) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("employeePersistenceUnit");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			EmployeeInfoBean employeeInfoBean= entityManager.find(EmployeeInfoBean.class, empId);
			entityManager.remove(employeeInfoBean);
			tx.commit();
			isDeleted = true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		entityManager.close();
		return isDeleted;
	}// End of deleteEmployee()

	@Override
	public List<EmployeeInfoBean> getAllEmployees() {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from EmployeeInfoBean";
		Query query = manager.createQuery(jpql);
		
		List<EmployeeInfoBean> employeesList = null;
		try {
			employeesList = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return employeesList;
		
	}// End of getAllEmployees()

}// end_of_class
