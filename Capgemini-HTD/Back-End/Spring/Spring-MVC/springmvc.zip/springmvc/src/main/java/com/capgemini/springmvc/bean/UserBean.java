package com.capgemini.springmvc.bean;

import java.util.Date;

public class UserBean {

	private int empId;
	private String empName;
	private String password;
	
	private Date dob;
	
	
	//getter and setter
	
	
	public int getEmpId() {
		return empId;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}// end of class
