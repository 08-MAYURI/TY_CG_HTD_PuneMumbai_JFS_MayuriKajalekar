package com.capgemini.mptspringboot.dao;

import java.util.List;

import com.capgemini.mptspringboot.beans.StudentAcademicBean;

public interface StudentDAO {
	public StudentAcademicBean getStudent(int sid);

	public StudentAcademicBean authenticate(int sid, String email, String password);

	public boolean addStudent(StudentAcademicBean studentAcademicBean);

	public boolean updateStudent(StudentAcademicBean studentAcademicBean);

	public boolean deleteStudent(int sid);

}
