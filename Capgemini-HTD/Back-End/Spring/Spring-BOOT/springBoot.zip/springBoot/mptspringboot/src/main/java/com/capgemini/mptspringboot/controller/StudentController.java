package com.capgemini.mptspringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.mptspringboot.beans.StudentAcademicBean;
import com.capgemini.mptspringboot.beans.StudentResponse;
import com.capgemini.mptspringboot.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	public StudentService service;

	@GetMapping(path = "/getStudent", produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public StudentAcademicBean getStudent(int sid) {
		StudentAcademicBean studentAcademicBean = service.getStudent(sid);
		StudentResponse Response = new StudentResponse();
		if (studentAcademicBean != null) {
			Response.setMsg("succesfully");
			Response.setDesc("Student Result Is Found");
			Response.setStudentAcademicBean(studentAcademicBean);
		}
		return studentAcademicBean;
	}// end of getStudent()

	@PutMapping(path = "/addStudent", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public StudentResponse addStudent(@RequestBody StudentAcademicBean studentAcademicBean) {
		boolean isAdded = service.addStudent(studentAcademicBean);

		StudentResponse response = new StudentResponse();

		if (isAdded) {
			response.setMsg("success");
			response.setDesc("student Added succesfully");
		} else {
			response.setMsg("failure");
			response.setDesc(" unable to add Student ");
		}
		return response;
	}// end of addStudent()

	@DeleteMapping(path = "/deleteStudent/{sid}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public StudentResponse deleteStudent(@PathVariable("stu-id") int sid) {
		boolean isDeleted = service.deleteStudent(sid);
		StudentResponse response = new StudentResponse();

		if (isDeleted) {
			response.setMsg("success");
			response.setDesc("Student deleted succesfully");
		} else {

			response.setMsg("failure");
			response.setDesc(" unable to delete Student");
		}

		return response;

	}// end of deleteStudent()

	@PostMapping(path = "/updateStudent", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public StudentResponse updateStudent(@RequestBody StudentAcademicBean studentAcademicBean) {
		boolean isUpdated = service.updateStudent(studentAcademicBean);
		StudentResponse response = new StudentResponse();

		if (isUpdated) {

			response.setMsg("success");
			response.setDesc("Student Updated succesfully");
		} else {

			response.setMsg("failure");
			response.setDesc(" Unable to update student details");
		}

		return response;
	}// end of updateStudent()

}
