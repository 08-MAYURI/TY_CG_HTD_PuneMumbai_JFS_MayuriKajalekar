package com.capgemini.mptspringboot.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.mptspringboot.beans.StudentAcademicBean;

@Repository
public class StudentDAOimpl implements StudentDAO {

	@PersistenceUnit
	private EntityManagerFactory emf;

	@Override
	public StudentAcademicBean getStudent(int sid) {
		EntityManager manager = emf.createEntityManager();
		StudentAcademicBean studentAcademicBean = manager.find(StudentAcademicBean.class, sid);
		manager.close();
		return studentAcademicBean;

	}

	@Override
	public StudentAcademicBean authenticate(int sid, String email, String password) {
		EntityManager manager = emf.createEntityManager();
		String jpql = "from StudentAcademicBean where sid = : sid and email = :email and password = :password";
		Query query = manager.createQuery(jpql);
		query.setParameter("sid", sid);
		query.setParameter("email", email);
		query.setParameter("password", password);

		StudentAcademicBean studentAcademicBean = null;
		try {
			studentAcademicBean = (StudentAcademicBean) query.getSingleResult();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return studentAcademicBean;
	}// End of authenticate()

	@Override
	public boolean addStudent(StudentAcademicBean studentAcademicBean) {
		EntityManager manager = emf.createEntityManager();
		EntityTransaction tx = manager.getTransaction();
		boolean isAdded = false;
		try {
			tx.begin();
			manager.persist(studentAcademicBean);
			tx.commit();
			isAdded = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		manager.close();

		return isAdded;
	}// End of addStudent()

	@Override
	public boolean updateStudent(StudentAcademicBean studentAcademicBean) {
		EntityManager manager = emf.createEntityManager();
		StudentAcademicBean existingStudentInfo = manager.find(StudentAcademicBean.class, studentAcademicBean.getSid());
		boolean isUpdated = false;

		if (existingStudentInfo != null) {
			String email = studentAcademicBean.getEmail();
			if (email != null) {
				existingStudentInfo.setEmail(email);
			}

			try {
				EntityTransaction tx = manager.getTransaction();
				tx.begin();
				manager.persist(existingStudentInfo);
				tx.commit();

				isUpdated = true;

			} catch (Exception e) {
				e.printStackTrace();
			}
			manager.close();
		}
		return isUpdated;
	}// End of updateStudent()

	@Override
	public boolean deleteStudent(int sid) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("studentPersistenceUnit");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction tx = entityManager.getTransaction();
			tx.begin();
			StudentAcademicBean studentAcademicBean = entityManager.find(StudentAcademicBean.class, sid);
			entityManager.remove(studentAcademicBean);
			tx.commit();
			isDeleted = true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		entityManager.close();
		return isDeleted;
	}// End of deleteEmployee()

}
