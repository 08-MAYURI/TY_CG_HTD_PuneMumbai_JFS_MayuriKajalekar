package com.capgemini.mptspringboot.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringBootController {

	@GetMapping(path="/hello", produces="text/plain")
	public String welcomeMessage() {
		
		return "welcome to Student Management Portal";
		
	}//end of welcomeMessage()
}
