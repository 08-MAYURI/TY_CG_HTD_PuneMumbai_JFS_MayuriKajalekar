package com.capgemini.mptspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MptspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MptspringbootApplication.class, args);
	}
}
