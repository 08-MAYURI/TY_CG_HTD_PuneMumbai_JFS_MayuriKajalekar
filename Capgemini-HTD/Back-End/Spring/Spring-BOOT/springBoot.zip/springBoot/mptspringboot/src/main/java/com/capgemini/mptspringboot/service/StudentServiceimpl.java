package com.capgemini.mptspringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.mptspringboot.beans.StudentAcademicBean;
import com.capgemini.mptspringboot.dao.StudentDAO;

@Service
public class StudentServiceimpl implements StudentService {

	@Autowired
	private StudentDAO dao;

	@Override
	public StudentAcademicBean getStudent(int sid) {
		return dao.getStudent(sid);
	}

	@Override
	public StudentAcademicBean authenticate(int sid, String email, String password) {
		return dao.authenticate(sid, email, password);
	}

	@Override
	public boolean addStudent(StudentAcademicBean studentAcademicBean) {
		return dao.addStudent(studentAcademicBean);
	}

	@Override
	public boolean updateStudent(StudentAcademicBean studentAcademicBean) {
		return dao.updateStudent(studentAcademicBean);
	}

	@Override
	public boolean deleteStudent(int sid) {
		return dao.deleteStudent(sid);
	}



}
