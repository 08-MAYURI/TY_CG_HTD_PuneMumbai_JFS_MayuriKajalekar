package com.capgemini.mptspringboot.beans;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class StudentResponse {
	private String msg;
	private String desc;
	private StudentAcademicBean studentAcademicBean;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public StudentAcademicBean getStudentAcademicBean() {
		return studentAcademicBean;
	}

	public void setStudentAcademicBean(StudentAcademicBean studentAcademicBean) {
		this.studentAcademicBean = studentAcademicBean;
	}

}
