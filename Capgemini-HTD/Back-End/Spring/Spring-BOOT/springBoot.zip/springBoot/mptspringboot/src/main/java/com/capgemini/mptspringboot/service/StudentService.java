package com.capgemini.mptspringboot.service;

import java.util.List;

import com.capgemini.mptspringboot.beans.StudentAcademicBean;

public interface StudentService {
	
	public StudentAcademicBean getStudent(int sid);

	public StudentAcademicBean authenticate(int sid, String email, String password);

	public boolean addStudent(StudentAcademicBean studentAcademicBean);

	public boolean updateStudent(StudentAcademicBean studentAcademicBean);

	public boolean deleteStudent(int sid);


}
