package com.capgemini.springrest.controller;

import java.awt.PageAttributes.MediaType;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springrest.bean.EmployeeInfoBean;
import com.capgemini.springrest.bean.EmployeeResponse;
import com.capgemini.springrest.service.EmployeeService;

//@Controller
@RestController
@CrossOrigin(origins = "+", allowedHeaders = "+")
public class EmployeeRestController {

	@Autowired
	private EmployeeService service;

	@GetMapping(path = "/getEmployee", produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	// @ResponseBody
	public EmployeeResponse getEmployee(int empId) {

		EmployeeInfoBean employeeInfoBean = service.getEmp(empId);
		EmployeeResponse response = new EmployeeResponse();
		if(employeeInfoBean !=null) {
			response.setStatusCode(210);
			response.setMessage("success");
			response.setDescription("employee record found");
			response.setEmployeeInfoBean(employeeInfoBean);
		}
		else {
			response.setStatusCode(210);
			response.setMessage("success");
			response.setDescription("employee record "+empId+"found");
		}
		return response;

	}// end of getAllEmployee

	@PutMapping(path = "/addEmployee", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = MediaType.APPLICATION_JSON_VALUE)
	// @ResponseBody
	public EmployeeResponse addEmployee(@RequestBody EmployeeInfoBean employeeBean) {
		boolean isAdded = service.addEmployee(employeeBean);
		EmployeeResponse response =new EmployeeResponse();
		if(isAdded) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("employee added successfully");
		}
		else {response.setStatusCode(204);
		response.setMessage("fail");
		response.setDescription("employee not added ");
	}
		return response;
		
	}// end of addEmployee

	@DeleteMapping(path = "/deleteEmployee", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	// @ResponseBody
	public EmployeeResponse deleteEmployee( int empId) {
		boolean isDeleted = service.deleteEmployee(empId);
		EmployeeResponse response =new EmployeeResponse();
		if(isDeleted) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("employee deleted successfully");
		}
		else {response.setStatusCode(204);
		response.setMessage("fail");
		response.setDescription("employee not deleted ");
	}
		return response;

	}// end of deleteEmployee

	@PostMapping(path = "/updateEmployee", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = MediaType.APPLICATION_JSON_VALUE)
	// @ResponseBody
	public EmployeeResponse updateEmployee(@RequestBody EmployeeInfoBean employeeBean) {
		boolean isUpdated =  service.updateEmployee(employeeBean);
		EmployeeResponse response =new EmployeeResponse();
		if(isUpdated) {
			response.setStatusCode(201);
			response.setMessage("success");
			response.setDescription("employee updated successfully");
		}
		else {response.setStatusCode(204);
		response.setMessage("fail");
		response.setDescription("employee not updated ");
	}
		return response;
	

	}// end of updateEmployee

	@GetMapping(path = "/getAll", produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public EmployeeResponse getAllEmployee() {
		List<EmployeeInfoBean> employeeList = service.getAllEmployees();
		EmployeeResponse response = new EmployeeResponse();
		if(employeeList != null && !employeeList.isEmpty()) {
			response.setStatusCode(210);
			response.setMessage("success");
			response.setDescription("employee record found");
			response.setEmployeeList(employeeList);
			
		}else {
			response.setStatusCode(210);
			response.setMessage("success");
			response.setDescription("employee record found");+
		}
		return response;
	}// end of getAllEMployee
}// end of controller
