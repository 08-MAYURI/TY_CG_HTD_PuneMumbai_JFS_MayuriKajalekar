package com.capgemini.queue.examples;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TestG {

	public static void main(String[] args) {

		ArrayList<Integer> al=new ArrayList<Integer>();
		
		al.add(6);
		al.add(15);
		al.add(16);
		al.add(18);
		al.add(4);
		
		List<Integer> li= al.stream().map(i->i*2).collect(Collectors.toList());
		
		for(Integer k:li) {
			System.out.println(k);
		}
	}

	}


