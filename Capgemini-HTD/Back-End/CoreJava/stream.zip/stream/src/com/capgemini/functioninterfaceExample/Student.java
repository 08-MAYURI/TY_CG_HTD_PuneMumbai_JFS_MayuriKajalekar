package com.capgemini.functioninterfaceExample;

public class Student {
	int id;
	String name;
	double percentage;
	
	Student(){
		
	}
	
	
	public Student(int id, String name, double percentage) {
		this.id = id;
		this.name = name;
		this.percentage = percentage;
	}
	

}
