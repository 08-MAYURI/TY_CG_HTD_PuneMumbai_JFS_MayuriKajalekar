package com.capgemini.functioninterfaceExample;

import java.util.function.Supplier;

public class TestD {
	public static void main(String[] args) {
		
		Supplier<Student> s=()->new Student();
		
		Student s1=s.get();
		
		System.out.println(s1);
		
		Student s2=s.get();
		
		System.out.println(s2);
		
		
		
		
		
	}

}
