package com.capgemini.sorting.setExample;

import java.util.HashSet;
import java.util.Iterator;

public class EmployeeTest {
	public static void main(String[] args) {
		
		HashSet<Employee> hs=new HashSet<Employee>();
		
		Employee e1=new Employee(1,"Dhanya",800.87);
		Employee e2=new Employee(2,"Theju",900.87);
		Employee e3=new Employee(3,"Nikita",500.87);
		Employee e4=new Employee(4,"Kavya",300.87);
		Employee e5=new Employee(2,"Theju",900.87);
		
		hs.add(e1);
		hs.add(e2);
		hs.add(e3);
		hs.add(e4);
		hs.add(e5);
		
		Iterator<Employee> it=hs.iterator();
		
		while(it.hasNext()) {
			Employee e=it.next();
			System.out.println("Id is "+e.id);
			System.out.println("Name is "+e.name);
			System.out.println("salary is "+e.salary);
			System.out.println("----------------------");
		}
		
		
				
	}

}
