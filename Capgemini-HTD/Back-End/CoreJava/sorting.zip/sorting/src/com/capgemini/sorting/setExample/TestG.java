package com.capgemini.sorting.setExample;

import java.util.Iterator;
import java.util.TreeSet;

public class TestG {

	public static void main(String[] args) {

		TreeSet<Employee1> ts=new TreeSet<Employee1>();

		Employee1 e1=new Employee1(1,"Dhanya",800.87);
		Employee1 e2=new Employee1(2,"Theju",900.87);
		Employee1 e3=new Employee1(3,"Nikita",500.87);
		Employee1 e4=new Employee1(4,"Kavya",300.87);
		Employee1 e5=new Employee1(2,"Theju",900.87);

		ts.add(e1);
		ts.add(e2);
		ts.add(e3);
		ts.add(e4);
		ts.add(e5);

		Iterator<Employee1> it=ts.iterator();

		while(it.hasNext()) {
			Employee1 e=it.next();
			System.out.println("Id is "+e.id);
			System.out.println("Name is "+e.name);
			System.out.println("salary is "+e.salary);
			System.out.println("----------------------");
		}




	}

}
