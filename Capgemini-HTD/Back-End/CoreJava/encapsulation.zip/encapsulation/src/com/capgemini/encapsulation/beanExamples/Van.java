package com.capgemini.encapsulation.beanExamples;

public class Van {
	
	private static Van ref=new Van();
	
	private Van() {
		
	}
	
	public static Van getVan() {
		return ref;
	}
	

}
