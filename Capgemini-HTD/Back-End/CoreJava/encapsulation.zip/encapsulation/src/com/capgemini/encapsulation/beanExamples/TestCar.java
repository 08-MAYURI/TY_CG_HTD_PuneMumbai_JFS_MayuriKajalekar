package com.capgemini.encapsulation.beanExamples;

public class TestCar {

	public static void main(String[] args) {

		Car c = new Car(20, "Benz");
		
		System.out.println("Cost is "+c.getCost());
		System.out.println("Name is "+c.getName());
	}

}
