package com.capgemini.encapsulation.beanExamples;

public final class BusImmutableClass {
	private final String name;
	private final int seats;

	public BusImmutableClass(String name, int seats) {

		this.name = name;
		this.seats = seats;
	}

	public String getName() {
		return name;
	}

	public int getSeats() {
		return seats;
	}

}
