package com.capgemini.exceptionhandling.examples;

public class TestE {
	public static void main(String[] args) {
		System.out.println("main started");

		int[] a = new int[3];

		try {
			System.out.println(a[2]);
			System.out.println(10/0);// here exception occurs so it will execute 2nd catch block
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("dont cross array boundry");
		} catch (ArithmeticException e) {
			System.out.println("dont devide by zero");
		}

		System.out.println("main ended");

}

}
