package com.capgemini.exceptionhandling.examples;

public class TestF {
	public static void main(String[] args) {
		System.out.println("main started");

		String s=null;
		int[] a = new int[3];

		try {
			System.out.println(s.toUpperCase());
			System.out.println(a[5]);//line 11 throws exception so it will not execute line 12
			System.out.println(10/0);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("dont cross array boundry");
		} catch (ArithmeticException e) {
			System.out.println("dont devide by zero");
		}catch (NullPointerException e) {
			System.out.println("dont deal with null");
		}

		System.out.println("main ended");

}

}
