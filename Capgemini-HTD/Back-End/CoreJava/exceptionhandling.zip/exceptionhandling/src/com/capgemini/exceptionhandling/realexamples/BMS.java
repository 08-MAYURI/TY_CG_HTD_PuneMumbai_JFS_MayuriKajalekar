package com.capgemini.exceptionhandling.realexamples;

public class BMS {
	public static void main(String[] args) {
		System.out.println("main started");
		PVR p = new PVR();
		try {
			p.confirm();
		} catch (ArithmeticException b) {
			System.out.println("Execution caught by main method");
		}
		System.out.println("main ended");
	}
	

}
