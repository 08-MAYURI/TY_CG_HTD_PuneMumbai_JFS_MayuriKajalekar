package com.capgemini.exceptionhandling.realexamples;

public class Test2 {
	public static void main(String[] args) {
		System.out.println("main started");
		int[] a = new int[2];
		String s = null;

		try {
			
			System.out.println(s.length());
			System.out.println(10 / 0);
			System.out.println(a[3]);

		} catch (ArrayIndexOutOfBoundsException |ArithmeticException |NullPointerException u)
		{
			u.printStackTrace();
		}

		System.out.println("main ended");
	}
}
