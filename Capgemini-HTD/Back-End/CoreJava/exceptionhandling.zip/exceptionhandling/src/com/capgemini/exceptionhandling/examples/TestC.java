package com.capgemini.exceptionhandling.examples;

public class TestC {
	public static void main(String[] args) {
		System.out.println("main started");

		int[] a = new int[3];

		try {
			System.out.println(a[2]);
			System.out.println(10/0);//here we not handle the arithmetic exception so main method terminated abnormally
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("dont cross array boundry");
		}

		System.out.println("main ended");

}
}
