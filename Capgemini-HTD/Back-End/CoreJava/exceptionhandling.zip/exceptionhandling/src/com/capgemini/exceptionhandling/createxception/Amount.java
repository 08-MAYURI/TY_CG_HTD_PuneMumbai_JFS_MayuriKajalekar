package com.capgemini.exceptionhandling.createxception;

public class Amount {
	
	void check(int a) throws InvalidLimitException  {
		
		if(a>40000) {
	throw new InvalidLimitException();
			
		}
	}

}
