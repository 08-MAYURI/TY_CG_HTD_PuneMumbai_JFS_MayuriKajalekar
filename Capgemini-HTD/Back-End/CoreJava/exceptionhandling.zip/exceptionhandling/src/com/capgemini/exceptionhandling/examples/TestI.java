package com.capgemini.exceptionhandling.examples;

public class TestI {
	public static void main(String[] args) {
		System.out.println("main started");

		String s="VikasSir";
		int[] a = new int[3];

		try {
			System.out.println(s.toUpperCase());
			System.out.println(a[2]);
			System.out.println(10/0);//AE exception occurs but we not define catch block for AE so it will handle by general catch block
		
		}catch (Exception e) {
			System.out.println("dont deal with null");//general catch block
		}
		/*catch (NullPointerException e) {
			System.out.println("don't deal with null");//NPE catch block
		}we cannot declare specific catch block after general catch block
        */
		System.out.println("main ended");

}



}
