package com.capgemini.exceptionhandling.realexamples;

public class PVR1 {
	void confirm1() {
		System.out.println("confirm sarted");

		try {
			System.out.println(10 / 0);
		} catch (ArithmeticException a) {
			System.out.println("Exception caught at confirm method");
			throw a;
		}

		finally {
			System.out.println("confirm ended");
		}

	}
}
