package com.capgemini.exceptionhandling.examples;

public class TestD {

	public static void main(String[] args) {
		System.out.println("main started");

		int[] a = new int[3];

		try {
			System.out.println(a[5]);//line 11 throws exception so it will not exexute line 12
			System.out.println(10/0);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("dont cross array boundry");
		} catch (ArithmeticException e) {
			System.out.println("dont devide by zero");
		}

		System.out.println("main ended");

}
}
