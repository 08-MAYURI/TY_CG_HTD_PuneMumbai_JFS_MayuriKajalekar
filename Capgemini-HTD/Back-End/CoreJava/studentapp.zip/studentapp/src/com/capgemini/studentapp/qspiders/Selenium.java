package com.capgemini.studentapp.qspiders;

public class Selenium {
	public void teachSelenium() {
		System.out.println("I am teach Selenium Method");
	}

}
