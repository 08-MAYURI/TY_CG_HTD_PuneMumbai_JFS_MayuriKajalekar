package com.capgemini.studentapp.qspiders;

import static com.capgemini.studentapp.jspiders.Remote.*;
//import static com.capgemini.studentapp.jspiders.Remote.sum;--To access sum static variable only

import com.capgemini.studentapp.jspiders.Remote;

public class TestD {
public static void main(String[] args) {
	on();
	System.out.println(sum);

	Remote R=new Remote();
	R.off();
	System.out.println(R.count);

}
}
