package com.capgemini.studentapp.jspiders;

public class TestB {
public static void main(String[] args) {
	
}
}
