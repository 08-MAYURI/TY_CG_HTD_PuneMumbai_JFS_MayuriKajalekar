package com.capgemini.studentapp.jspiders;

public class Remote {
	public static int sum=100;
	
	public int count=200;
	public static void on() {
		System.out.println("I am on() method");
	}
	public static void off() {
		System.out.println("I am off() method");
	}


}
