package com.capgemini.objectclass.methods;

public class Marker extends Pen {

}
