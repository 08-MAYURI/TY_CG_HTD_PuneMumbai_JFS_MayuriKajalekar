package com.capgemini.objectclass.methods;

public class TestE {

	public static void main(String[] args) {
		
		Product a= new Product();
		a.id=1;
		a.name="Pencil";
		a.type="lead";
		a.brand="Apsara";
		a.cost=5;
		

		Product b= new Product();
		b.id=2;
		b.name="Pencil";
		b.type="lead";
		b.brand="Apsara";
		b.cost=10;
		

		Product c= new Product();
		c.id=3;
		c.name="Pen";
		c.type="gel";
		c.brand="reynolds";
		c.cost=10;
		

		Product d= new Product();
		a.id=1;
		a.name="Pencil";
		a.type="lead";
		a.brand="Apsara";
		a.cost=5;
		
		System.out.println(a.equals(b));
		System.out.println(a.equals(c));
		System.out.println(a.equals(d));
		
		
		

	}

}
