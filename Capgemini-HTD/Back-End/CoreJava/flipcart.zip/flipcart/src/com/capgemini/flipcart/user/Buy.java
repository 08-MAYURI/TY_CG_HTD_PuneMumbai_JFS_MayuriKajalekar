package com.capgemini.flipcart.user;

public class Buy {

}
