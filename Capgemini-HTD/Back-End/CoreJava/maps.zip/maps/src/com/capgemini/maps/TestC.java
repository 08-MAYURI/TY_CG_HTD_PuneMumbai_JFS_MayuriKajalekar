package com.capgemini.maps;

import java.util.Map;
import java.util.TreeMap;

public class TestC {
public static void main(String[] args) {
	

	TreeMap<String,Integer> hm=new TreeMap<String,Integer>();
	
	hm.put("Ondhu", 1);
	hm.put("Idhu", 5);
	hm.put("Hattu", 10);
	hm.put("Eredu", 2);
	
	for(Map.Entry<String,Integer> me :hm.entrySet()) {
		String k=me.getKey();
		Integer t=me.getValue();
	System.out.println("Key is "+k);
	System.out.println("Value is "+t);
	System.out.println("--------------------------");
		
	}
}
}
