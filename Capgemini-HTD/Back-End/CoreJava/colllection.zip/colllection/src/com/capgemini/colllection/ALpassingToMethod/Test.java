package com.capgemini.colllection.ALpassingToMethod;

import java.util.HashSet;
import java.util.Set;

public class Test {

	public static void main(String[] args) {
Set num=new HashSet<String>();
num.add("5");
num.add(5); 
System.out.println(num);
}

}
