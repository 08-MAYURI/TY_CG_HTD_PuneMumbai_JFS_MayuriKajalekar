package com.capgemini.array.examples;

public class D {
	public static void main(String[] args) {

		int[] i = chinnu();
		for (int j : i) {
			System.out.println(j);
		}
	}

	static int[] chinnu() {
		int[] a = { 1, 2, 3, 4, 5 };
		return a;
	}
}
