package com.capgemini.array.examples;

public class B {

	public static void main(String[] args) {
		char ch[]= {'a','b','c','d'};
		
		for(char a:ch) {
			System.out.println(a);
		}
		
		double d[]= {1.2,1.3,1.4,1.4};
		

		for(double k:d) {
			System.out.println(k);
		}
		
		double i[]=new double[4];
		i[2]=100;
		for(double j:i) {
			System.out.println(j);
		}
		
		
	}

}
