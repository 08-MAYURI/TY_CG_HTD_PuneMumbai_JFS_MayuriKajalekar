package com.capgemini.array.examples;

public class Mouse {
	void walk(double[] a) {
		for (double c : a) {
			System.out.println(c);
		}

	}

	void run(int[] b) {
		for (int d : b) {
			System.out.println(d);
		}

	}
	
	void onlyOdd(int[] c) {
		for(int e:c) {
			if(e%2!=0) {
			System.out.println(e);
		}
	}
}
}
