package com.capgemini.array.examples;

public class Test1 {

	public static void main(String[] args) {

		Mouse m = new Mouse();
		double[] i = { 1.1, 1.2, 1.3 };
		int[] j = { 1, 2, 3, 4 };

		m.walk(i);
System.out.println("---------------------");
		m.run(j);
		System.out.println("---------------------");
	}
}
