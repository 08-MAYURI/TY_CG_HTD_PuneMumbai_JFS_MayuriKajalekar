package com.capgemini.collectionframework.list;

import java.util.ListIterator;
import java.util.Vector;

public class TestQ {

	public static void main(String[] args) {

		Vector<Character> v=new Vector<Character>();
		
		v.add('A');
		v.add('P');
		v.add('P');
		v.add('L');
		v.add('E');
		
		System.out.println("*****for loop******");
		
		for(int i=0;i<5;i++) {
			Character r=v.get(i);
			System.out.println(r);
		}
		
		System.out.println("*****for-each loop******");
		
		for(Character r: v) {
			System.out.println(r);
		}
		
		System.out.println("*****Iterator******");
		
		ListIterator<Character> it=v.listIterator();
		
		while(it.hasNext()) {
			Character r=it.next();
			System.out.println(r);
		}
		
		System.out.println("*****List Operator******");
		
		System.out.println("----------------> Forward");
		
		while(it.hasNext()) {
			Character r=it.next();
			System.out.println(r);
		}
		
		System.out.println("<------------------ Backward");
		
		while (it.hasPrevious()) {
			Object r = it.previous();
			System.out.println(r);
	}
	

}
}
