package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.ListIterator;

public class TestE {

	public static void main(String[] args) {

		ArrayList al=new ArrayList();
		al.add(24);
		al.add("chinnu");
		al.add(2.9);
		al.add('F');
		
		ListIterator li=al.listIterator();
		
		while(li.hasNext()) {
			Object r=li.next();
			System.out.println(r);
		}
		
	}

}
