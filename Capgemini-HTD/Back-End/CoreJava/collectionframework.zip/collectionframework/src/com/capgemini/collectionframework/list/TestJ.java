package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class TestJ {

	public static void main(String[] args) {

		ArrayList<Double> ald = new ArrayList<Double>();
		ald.add(2.1232);
		ald.add(23.45);
		ald.add(234.43);
		ald.add(5.44);

		for (int i = 0; i < 4; i++) {
			Double r = ald.get(i);// Here we use generic array list so specific return type is mentioned
			System.out.println(r);
		}
	}

}
