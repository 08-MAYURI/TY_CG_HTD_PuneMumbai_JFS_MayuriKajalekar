package com.capgemini.collectionframework.list;

import java.util.ArrayList;

public class TestA {
	public static void main(String[] args) {
		
	
	
	ArrayList al=new ArrayList();
	
	al.add(1221);
	al.add("chinnu");
	al.add(2.9);
	al.add('F');
	
	Object a=al.get(0);
	System.out.println(a);
	
	Object b=al.get(1);
	System.out.println(b);
	
	Object c=al.get(2);
	System.out.println(c);
	
	Object d=al.get(3);
	System.out.println(d);
	
	/*Object e=al.get(4);
	System.out.println(e);
	it throws IndexOutOfBoundExceptyion
	*/
	
	for(int i=0;i<4;i++) {
		Object r=al.get(i);
		System.out.println(r);
	}
	
	

}
}
