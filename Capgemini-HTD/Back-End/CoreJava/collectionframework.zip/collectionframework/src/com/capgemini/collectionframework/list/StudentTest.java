package com.capgemini.collectionframework.list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class StudentTest {

	public static void main(String[] args) {

		ArrayList<Student> als = new ArrayList<Student> ();

		Student s1 = new Student(1, "Dhanu", 80.23);
		Student s2 = new Student(2, "Shruti", 80.23);
		Student s3 = new Student(3, "Shubhangi", 80.23);
		Student s4 = new Student(4, "Shital", 80.23);
		Student s5 = new Student(5, "Aishwarya", 80.23);
		Student s6 = new Student(6, "Priti", 80.23);
		Student s7 = new Student(7, "Simran", 80.23);
		
		als.add(s1);
		als.add(s2);
		als.add(s3);
		als.add(s4);
		als.add(s5);
		als.add(s6);
		als.add(s7);

		System.out.println("*******for loop*******");

		for (int i = 0; i < 6; i++) {
			Student s = als.get(i);
			System.out.println("Id is: " + s.id);
			System.out.println("Name is: " + s.name);
			System.out.println("Percentage is: " + s.percentage);
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		}
		
		System.out.println("*******for-each loop*******");
		
		for (Student s : als) {

			
			System.out.println("Id is: " + s.id);
			System.out.println("Name is: " + s.name);
			System.out.println("Percentage is: " + s.percentage);
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

		}
		
		System.out.println("*******Iterator*******");

		Iterator<Student> its=als.iterator();
		
		while(its.hasNext()) {
			Student s=its.next();
			System.out.println("Id is: " + s.id);
			System.out.println("Name is: " + s.name);
			System.out.println("Percentage is: " + s.percentage);
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			
		}
		
		System.out.println("*******List Iterator*******");
		
		ListIterator<Student> lis=als.listIterator();
		System.out.println("--------------------->forward");
		while(lis.hasNext()) {
			Student s=lis.next();
			System.out.println("Id is: " + s.id);
			System.out.println("Name is: " + s.name);
			System.out.println("Percentage is: " + s.percentage);
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			
		}
		
		System.out.println("<----------------------backward");
		while(lis.hasPrevious()) {
			Student s=lis.previous();
			System.out.println("Id is: " + s.id);
			System.out.println("Name is: " + s.name);
			System.out.println("Percentage is: " + s.percentage);
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			
		}
		
		
		
		
		
		
		
		
		
		
	}

}
