package com.capg.corejava.inheritance;

public abstract class Demo {

public abstract void print();
public abstract void add();
}
