package com.capg.corejava.vikas;

public class TestC {

	public static void main(String[] args) {
		Machine m=new Machine();
		ICICI i=new ICICI();
		HDFC h=new HDFC();
		SBI s=new SBI();
		
		m.slot(i);
		m.slot(h);
		m.slot(s);
	}

}
