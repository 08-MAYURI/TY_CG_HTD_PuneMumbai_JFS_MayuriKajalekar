package com.capg.corejava.vikas;

public   class Baby  {
	void receive(Chips c){
		c.open();
		c.eat();
	}


}
