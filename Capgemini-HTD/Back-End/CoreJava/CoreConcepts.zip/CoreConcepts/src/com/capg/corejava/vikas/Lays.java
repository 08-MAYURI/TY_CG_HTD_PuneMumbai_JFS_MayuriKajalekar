package com.capg.corejava.vikas;

public class Lays implements Chips {

	@Override
	public void open() {
	System.out.println("I am opening lays");
		
	}

	@Override
	public void eat() {
		System.out.println("I am eating Lays");
		
	}
	
	

}
