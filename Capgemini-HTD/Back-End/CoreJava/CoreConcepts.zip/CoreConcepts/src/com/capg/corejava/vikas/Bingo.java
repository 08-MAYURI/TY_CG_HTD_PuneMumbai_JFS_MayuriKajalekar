package com.capg.corejava.vikas;

public class Bingo implements Chips {

	public void open() {
		System.out.println("I am opening Bingo");
	}

	@Override
	public void eat() {
		System.out.println("I am eating Bingo");
	}

}
