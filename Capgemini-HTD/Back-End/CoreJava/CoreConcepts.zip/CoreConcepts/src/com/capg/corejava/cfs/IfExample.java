package com.capg.corejava.cfs;

public class IfExample {

	public static void main(String[] args) {
		int i = 5;
		int j = 15;
		if (i < 10) {
			System.out.println("i is single digit");
		}
		else {
			System.out.println("i is not single digit");
		}
		if (j > 10) {
			System.out.println("j is not single digit");
		}
		else {
			System.out.println("j is single digit");
		}

		System.out.println("Execution completed");

	}

}
