package com.capg.corejava.inheritance;

public interface InterfacesExample {
public void display();
public void show();
	/*
	 * public static void print() {
	 * 
	 * }if we having static method then it is normal method
	 */
}

