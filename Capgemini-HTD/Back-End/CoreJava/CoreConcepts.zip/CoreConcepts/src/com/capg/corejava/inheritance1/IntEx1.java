package com.capg.corejava.inheritance1;

public interface IntEx1 {
	public void print();
	void printNum();

	default void display() {
		System.out.println("Default Method of Interface");
	}

	public static void show() {
		System.out.println("staic method of Interface");
	}
	
	
}
