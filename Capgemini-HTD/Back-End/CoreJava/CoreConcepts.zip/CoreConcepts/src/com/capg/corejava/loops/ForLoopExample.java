package com.capg.corejava.loops;

public class ForLoopExample {

	public static void main(String[] args) {
		int j;
		for (int i = 1; i <= 10; i++) {
			if(i%2==0)
		        System.out.println(" i is even");
			else
				System.out.println(" i is odd");
				
		}
		for ( j = 1; j<= 10 ; ) {
			System.out.println("j=" + j);
			j++;
		}
		/*int k=1;
		for( ; ; ) {
				System.out.println(++k);
			}
		} it will go in infinite loop */
		
		System.out.println("Code Outside for loop");
		
		int a=5;
		if(a<50)
		{
			for(int b=1; b<a; b++) {
				System.out.println(b+" is less than " +a);
			}
		}

	}
	
}
