package com.capg.corejava.vikas;

public class Machine {
void slot(ATM a) {
	a.validateCard();
	a.getInfo();
	
}
}
