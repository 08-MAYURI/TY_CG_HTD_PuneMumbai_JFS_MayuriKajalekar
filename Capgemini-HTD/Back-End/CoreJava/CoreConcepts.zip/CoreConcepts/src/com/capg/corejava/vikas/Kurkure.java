package com.capg.corejava.vikas;

public class Kurkure implements Chips {

	@Override
	public void open() {
	System.out.println("I am eating kurkure");

	}

	@Override
	public void eat() {
		System.out.println("I am eating kurkure");
	}

}
