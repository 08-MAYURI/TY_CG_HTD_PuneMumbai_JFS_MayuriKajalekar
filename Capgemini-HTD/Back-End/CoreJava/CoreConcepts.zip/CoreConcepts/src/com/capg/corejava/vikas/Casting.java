package com.capg.corejava.vikas;

public class Casting {
	public static void main (String[] args) {
		Pen p=new Marker();
		p.write();
		System.out.println("cost is "+p.cost);
	
		Marker m=(Marker)p;
		m.write();
		System.out.println("cost is "+m.cost);
		m.color();
		System.out.println("size is "+m.size);
		
		
		
		
		
	}

}
