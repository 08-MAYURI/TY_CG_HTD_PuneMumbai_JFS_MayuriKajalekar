package com.capg.corejava.basics;

public class ArithmeticOperators {

	public static void main(String[] args) {
		int i = 100, j = 200;
		int res = i + j;// addition
		System.out.println("i+j= " + res);
		res = i - j;// subtraction 
		System.out.println("i-j=" + res);
		res = i * j;// multiplication
		System.out.println("i*j=" + res);
		res = i / j;// division
		System.out.println("i/j=" + res);
		res = i % j;// modulus
		System.out.println("i%j=" + res);

	}

}
