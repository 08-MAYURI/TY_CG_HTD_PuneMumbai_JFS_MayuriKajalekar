package com.capg.corejava.vikas;

public class Pen {

	int cost=100;
	void write() {
		System.out.println("Pen is used to writing");
		

	}

}
