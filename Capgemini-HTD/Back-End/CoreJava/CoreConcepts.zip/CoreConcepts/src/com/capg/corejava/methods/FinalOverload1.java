package com.capg.corejava.methods;

public class FinalOverload1 {
	final void method(int a) {
		System.out.println("Superclass");
	}

}
