package com.capgemin.jdbc.controller;

import java.util.Scanner;

import com.capgemin.jdbc.beans.UserBean;
import com.capgemini.jdbc.dao.UserDAO;
import com.capgemini.jdbc.factory.UserFactory;

public class LoginUser {
	public static void main(String[] args) {
		
	
	
	Scanner sc=new Scanner(System.in);
	UserDAO dao=UserFactory.getInstance();
	System.out.println("Enter userid...........");
	int userid=Integer.parseInt( sc.nextLine());
	
	System.out.println("Enter password.........");
	String password=sc.nextLine();

	UserBean user=dao.userLogin(userid,password);
	//UserBean user=dao.userLogin(sc.nextInt(), sc.nextLine());
	if(user!=null) {
		System.out.println(user);
	}else {
		System.out.println("Someting went wrong......................");
	}
	
	sc.close();
}

}
