package com.capgemini.jdbc;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JDBCRetivalAll {

	public static void main(String[] args) {

		Connection conn = null;
		FileReader reader = null;
		Properties prop = null;
		Statement stmt = null;
		ResultSet res = null;

		try {
			reader = new FileReader("C:\\Users\\Simran\\Desktop\\db.properties");
			prop = new Properties();
			prop.load(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			
			// Get the connection

			String dbURL = "jdbc:mysql://127.0.0.1:3306/capg_db";
			conn = DriverManager.getConnection(dbURL, prop);
			System.out.println("connection estd.....................");
			System.out.println("**********************************");

			// issue sql query

			String query = "select * from users_info";
			stmt = conn.createStatement();
			res = stmt.executeQuery(query);

			// Process the results returned by the SQL query

			while (res.next()) {
				System.out.println("User id: " + res.getInt(1));
				System.out.println("User name : " + res.getString("username"));
				System.out.println("Email is: " + res.getString("email"));
				System.out.println("Password is: " + res.getString("password"));
				System.out.println("******************************");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}   else if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} else if (res != null) {
				try {
					res.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

}
