package com.capgemini.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CollableExample {

	public static void main(String[] args) {
		Connection conn = null;
		Scanner sc = new Scanner(System.in);
		CallableStatement cstmt = null;
		ResultSet res = null;

		try {
			// Load the Driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded......");
			System.out.println("**************************");

			// Get the connection
			String dbURL = "jdbc:mysql://localhost:3306/capg_db";
			System.out.println("Enter user and password..");
			String user = sc.nextLine();
			String password = sc.nextLine();
			conn = DriverManager.getConnection(dbURL, user, password);
			System.out.println("*******************************");

			// issue SQL query
			String query = ("call getAllInfo()");
			cstmt = conn.prepareCall(query);
			boolean b = cstmt.execute();

			if (b) {
				res = cstmt.getResultSet();
				while (res.next()) {
					System.out.println("Userid: " + res.getInt(1));
					System.out.println("Username: " + res.getString(2));
					System.out.println("Email: " + res.getString(3));
					System.out.println("Password: " + res.getString(4));
					System.out.println("*****************************************");
				}
			} else {
				int i = cstmt.executeUpdate();
				if (i > 0) {
					System.out.println("Operation successsfull.......");
				}
			}

		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (cstmt != null) {
				try {
					cstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (res != null) {
				try {
					res.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

	}

}
}