
package com.capgemini.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class JDBCgetConneOnotherWay {

	public static void main(String[] args) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		Scanner sc = new Scanner(System.in);
		ResultSet res = null;
		try {
			// load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded.............");
			System.out.println("********************************");

			// Get the connection
			String dbURL = "jdbc:mysql://localhost:3306/capg_db";
			System.out.println("enter username and password");
			String user = sc.nextLine();
			String password = sc.nextLine();
			conn = DriverManager.getConnection(dbURL, user, password);
			System.out.println("connection established..........");
			System.out.println("***************");

			// Issue SQL queries via connection
			String query = "SELECT * FROM users_info where userid=?";
			pstmt = conn.prepareStatement(query);
			System.out.println("Enter user id");
			pstmt.setInt(1, sc.nextInt());
			res = pstmt.executeQuery();

			// process the results
			if (res.next()) {
				System.out.println("userid is " + res.getInt(1));
				System.out.println("User name : " + res.getString(2));
				System.out.println("Email is: " + res.getString(3));
				System.out.println("Password is: " + res.getString(4));
				System.out.println("******************************");

			} else {
				System.out.println("something went wrong");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (res != null) {
				try {
					res.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				sc.close();
			}
		}

	}

}
