package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.hibernate.metamodel.model.domain.spi.SetPersistentAttribute;

public class UpdateDynamicallyDemo {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Simran");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tr = em.getTransaction();
		String jpql = "update Movie set rating=:rate where id=:mid";
		tr.begin();
		Query query = em.createQuery(jpql);
		query.setParameter("rate", "flop");
		query.setParameter("mid", 1);
		Integer res = query.executeUpdate();

		System.out.println(res);

		tr.commit();
		em.close();

	}

}
