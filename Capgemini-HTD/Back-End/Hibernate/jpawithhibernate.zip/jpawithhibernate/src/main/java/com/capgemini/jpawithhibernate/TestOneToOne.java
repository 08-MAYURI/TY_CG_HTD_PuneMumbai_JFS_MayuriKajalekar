package com.capgemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.onetoone.Person;
import com.capgemini.jpawithhibernate.onetoone.VoterCard;

public class TestOneToOne {
	public static void main(String[] args) {

		/*this is for insertion
		Person p = new Person();
		p.setPid(2);
		p.setName("Ramesh");
		VoterCard vc = new VoterCard();
		vc.setVid(3259);
		vc.setVAdress("Gandhi Nagar");
		p.setVoterCard(vc);
         */
		EntityTransaction transaction = null;
		EntityManager entityManager = null;

		try {
			EntityManagerFactory entityManageFactory = Persistence.createEntityManagerFactory("Simran");
			entityManager = entityManageFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();
			//entityManager.persist(p); ------for insertion
			
			VoterCard cd=entityManager.find(VoterCard.class,1234);
			System.out.println(cd.getVid());
			System.out.println(cd.getVAdress());
			System.out.println(cd.getPerson().getPid());
			System.out.println(cd.getPerson().getName())
			
			;
		
			System.out.println("Record saved");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();

			e.printStackTrace();
		} finally {
			entityManager.close();
		}
	}
}
