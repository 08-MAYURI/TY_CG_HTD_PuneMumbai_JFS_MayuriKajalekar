package com.capgemini.jpawithhibernate;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.manytomany.Course;
import com.capgemini.jpawithhibernate.manytomany.Student1;

public class TestManyToMany {
	public static void main(String[] args) {
		Course c=new Course();
		c.setCid(101);
		c.setCname("java");
		
		Course c1=new Course();
		c1.setCid(102);
		c1.setCname("sql");
		
		ArrayList<Course> al=new ArrayList<Course>();
		al.add(c);
		al.add(c1);
		
		Student1 s=new Student1();
		s.setSid(1);
		s.setSname("Hayat");
	    s.setCourse(al);
	    
		Student1 s1=new Student1();
		s1.setSid(2);
		s1.setSname("Murad");
		s1.setCourse(al);
		
		Student1 s2=new Student1();
		s2.setSid(3);
		s2.setSname("Apec");
		s2.setCourse(al);
	
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Simran");
		EntityManager em=emf.createEntityManager();
		EntityTransaction tr=em.getTransaction();
		tr.begin();
		em.persist(s);
		em.persist(s1);
		em.persist(s2);
		em.persist(c);
		em.persist(c1);
		
		/*Course crs=em.find(Course.class, 101);
		System.out.println(crs.getStudent().get(0).getSid());
		System.out.println(crs.getStudent().get(0).getSname());
		System.out.println(crs.getStudent().get(1).getSid());
		System.out.println(crs.getStudent().get(1).getSname());
		System.out.println(crs.getStudent().get(2).getSid());
		System.out.println(crs.getStudent().get(2).getSname());
	*/
		System.out.println("data inserted");
		tr.commit();
		em.close();
		
	}

}
