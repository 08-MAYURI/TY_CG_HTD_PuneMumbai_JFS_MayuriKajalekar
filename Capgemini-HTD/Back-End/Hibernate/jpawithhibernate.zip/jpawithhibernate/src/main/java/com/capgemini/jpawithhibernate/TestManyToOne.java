package com.capgemini.jpawithhibernate;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.onetomany.Pencil;
import com.capgemini.jpawithhibernate.onetomany.PencilBox;

public class TestManyToOne {

	public static void main(String[] args) {

		/*For Many to one
		  PencilBox pb=new PencilBox();
		pb.setBoxid(106);
		pb.setBname("Apsara");
		Pencil p = new Pencil();
		p.setPid(9);
		p.setColor("Black");
		p.setPencilBox(pb);
		Pencil p1=new Pencil();
		p1.setPid(10);
		p1.setColor("Gray");
		p1.setPencilBox(pb);
		*/
		EntityTransaction transaction = null;
		EntityManager entityManager = null;

		try {
			EntityManagerFactory entityManageFactory = Persistence.createEntityManagerFactory("Simran");
			entityManager = entityManageFactory.createEntityManager();
			/*transaction = entityManager.getTransaction();
			transaction.begin();
			entityManager.persist(p);
			entityManager.persist(p1);
			//Pencil p3=entityManager.find(Pencil.class, 3);
			p3.setPencilBox(pb);
			*/
			Pencil p=entityManager.find(Pencil.class,1);
			System.out.println(p.getPid());
			System.out.println(p.getColor());
		
			
			
			System.out.println("Record updated");
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();

			e.printStackTrace();
		} finally {
			entityManager.close();
		}
	}

}
