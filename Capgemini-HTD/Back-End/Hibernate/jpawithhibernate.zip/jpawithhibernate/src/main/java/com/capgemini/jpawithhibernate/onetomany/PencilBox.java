package com.capgemini.jpawithhibernate.onetomany;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="PencilBox")
public class PencilBox {
	
	@Id
	@Column
	private int boxid;
	@Column 
	private String bname;

	public int getBoxid() {
		return boxid;
	}

	public void setBoxid(int boxid) {
		this.boxid = boxid;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}
	
	@OneToMany(mappedBy="pencilBox")
	private List<Pencil> pencil;

	public List<Pencil> getPencil() {
		return pencil;
	}

	public void setPencil(List<Pencil> pencil) {
		this.pencil = pencil;
	}


}
