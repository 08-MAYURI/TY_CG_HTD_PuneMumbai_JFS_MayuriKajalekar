package com.capgemini.jpawithhibernate.onetoone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "VoterCard")
public class VoterCard {
	@Id
	@Column
	private int vid;
	@Column
	private String VAdress;

	public int getVid() {
		return vid;
	}

	public void setVid(int vid) {
		this.vid = vid;
	}

	public String getVAdress() {
		return VAdress;
	}

	public void setVAdress(String VAdress) {
		this.VAdress = VAdress;
	}
	
	@OneToOne(mappedBy="voterCard")
	private Person person;

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	} 

}
