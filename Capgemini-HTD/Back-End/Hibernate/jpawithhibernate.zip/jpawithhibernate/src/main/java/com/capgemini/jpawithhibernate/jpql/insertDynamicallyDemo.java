package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class insertDynamicallyDemo {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Simran");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tr = em.getTransaction();
		String jpql = "insert into Movie (id,name,rating) values(:mid,:name,:rate)";
		tr.begin();
		Query query = em.createQuery(jpql);
		query.setParameter("mid", 7);
		query.setParameter("name","Hungama");
		query.setParameter("rate", "hit");
		Integer res = query.executeUpdate();

		System.out.println(res);

		tr.commit();
		em.close();

	}

}
