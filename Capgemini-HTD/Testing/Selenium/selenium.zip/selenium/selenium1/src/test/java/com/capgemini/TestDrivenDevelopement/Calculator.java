package com.capgemini.TestDrivenDevelopement;

public class Calculator {

	public int add(int a,int b) {
		return a+b;
	}
}
