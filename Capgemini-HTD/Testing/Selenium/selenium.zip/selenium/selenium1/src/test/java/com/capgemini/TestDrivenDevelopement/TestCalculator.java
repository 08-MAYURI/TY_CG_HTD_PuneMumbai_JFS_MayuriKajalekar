package com.capgemini.TestDrivenDevelopement;

import org.junit.Assert;
import org.junit.Test;

public class TestCalculator {

	@Test
	public void addTest() {
		{
			 Calculator cal =new Calculator();
			 int a=10;
			 int b=20;
			 int expected=30;
			 int actual=cal.add(a,b);
			 Assert.assertEquals(expected,actual);
		}
	}
}
