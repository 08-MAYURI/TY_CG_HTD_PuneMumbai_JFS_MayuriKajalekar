package com.capgemini.selenium.basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdown {
	
	public static void main(String[] args) throws InterruptedException {
	
	WebDriver driver = new FirefoxDriver();
	driver.get("file:///C://Users//mayuri//Desktop//foodSelenium.html");//path of html file that you have created
	
	WebElement listBox =driver.findElement(By.id("slv"));
	Select select =new Select(listBox);
	Thread.sleep(1000);
	select.selectByIndex(0);
	Thread.sleep(1000);
	select.selectByValue("v");
	Thread.sleep(1000);
	select.selectByVisibleText("Dosa");
	Thread.sleep(1000);
	select.deselectByIndex(0);
	Thread.sleep(1000);
	select.deselectByValue("v");
	Thread.sleep(1000);
	select.deselectByVisibleText("Dosa");
	}
}
