package com.capgemini.selenium.basic;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Gmail {
	
	static {
		System.setProperty("webdriver.gecko.driver","./driver/geckodriver.exe");
	}

	public static void main(String[] args) {
		
		WebDriver driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		//enter url
		driver.get("https://www.gmail.com");
		//enter valid username
		driver.findElement(By.id("identifierId")).sendKeys("kaakansha74@gmail.com");
		//click on text
		WebDriverWait wait = new WebDriverWait(driver, 100);
	    
	    driver.findElement(By.xpath("//span[text()='Next']")).click();
	    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@type='password']")));
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='password']")));
	    
	    WebElement elementpwd = driver.findElement(By.xpath("//input[@type='password']"));
	    		elementpwd.sendKeys("aakansha@123");
	    driver.findElement(By.xpath("//span[text()='Next']")).click();
	}
}		
