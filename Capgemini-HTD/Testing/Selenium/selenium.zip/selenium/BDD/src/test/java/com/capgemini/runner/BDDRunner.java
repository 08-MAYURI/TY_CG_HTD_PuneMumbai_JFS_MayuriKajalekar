package com.capgemini.runner;

import cucumber.api.CucumberOptions;

@CucumberOptions(features ="features",glue= {"com.capgemini.StepDefination"})
public class BDDRunner{

}
