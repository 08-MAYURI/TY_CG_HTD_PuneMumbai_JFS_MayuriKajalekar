package com.capgemini.StepDefination;

import org.openqa.selenium.WebDriver;

public class LoginStepDefination {

	static {
		System.setProperty("webdriver.gecko.driver","./BDD/geckodriver.exe");
	}

	WebDriver driver;
	
	

}
