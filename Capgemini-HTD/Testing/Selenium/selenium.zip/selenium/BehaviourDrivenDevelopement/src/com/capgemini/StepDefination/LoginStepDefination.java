package com.capgemini.StepDefination;

public class LoginStepDefination {

//	static {
//		System.setProperty("webdriver.gecko.driver",)
//	}
}
